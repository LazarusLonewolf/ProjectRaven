CREATE TABLE memories (
  id TEXT PRIMARY KEY,
  tier TEXT CHECK(tier IN ('session','mid_term','long_term','vault')),
  type TEXT,
  text_snippet TEXT,
  verbatim_excerpt TEXT,
  neutral_summary TEXT,
  tags JSON,
  emotion_tags JSON,
  intensity INTEGER,
  created_at TIMESTAMP,
  ttl_at TIMESTAMP NULL,
  pinned BOOLEAN,
  source TEXT,
  sensitivity TEXT CHECK(sensitivity IN ('public','private','vault'))
);