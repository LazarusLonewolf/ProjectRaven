def score(memory, query):
    recency = 1 / (1 + days_since(memory.created_at))
    similarity = cosine_similarity(embedding(memory.text), embedding(query))
    salience = memory.intensity/10 + memory.mention_count/5
    return 0.4*recency + 0.4*similarity + 0.2*salience