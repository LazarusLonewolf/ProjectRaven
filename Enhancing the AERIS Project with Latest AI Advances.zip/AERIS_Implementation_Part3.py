# AERIS Complete Implementation - Part 3
# =======================================
# Modes, Sandbox, API, and remaining core modules

# ============================================================================
# FILE: aeris/modes/mode_engine.py
# Mode system for different interaction contexts
# ============================================================================

import asyncio
from typing import Dict, Any, Optional, List
from enum import Enum
from pathlib import Path
import json
import logging

logger = logging.getLogger(__name__)


class InteractionMode(str, Enum):
    """Available interaction modes"""
    COMFORT = "comfort"
    MUSE = "muse"
    SHADOW = "shadow"
    INTIMACY = "intimacy"
    CHILDSAFE = "childsafe"


class ModeConfiguration:
    """Configuration for an interaction mode"""
    
    def __init__(self, mode: InteractionMode, config: Dict[str, Any]):
        self.mode = mode
        self.config = config
        
        # Extract settings
        self.name = config.get('name', mode.value)
        self.description = config.get('description', '')
        self.permissions = config.get('permissions', {})
        self.style = config.get('style', {})
        self.safety = config.get('safety', {})
        self.tools = config.get('tools', [])
        self.locked = config.get('locked', False)
        
        # Response templates
        self.templates = config.get('templates', {})
        
        # Lens weights for this mode
        self.lens_weights = config.get('lens_weights', {
            'trauma': 0.25,
            'emotional': 0.25,
            'scientific': 0.20,
            'logical': 0.20,
            'spiritual': 0.10
        })


class ModeEngine:
    """
    Manages interaction modes and their configurations.
    Each mode provides different interaction styles and capabilities.
    """
    
    def __init__(self, config: Dict[str, Any] = None, bus = None):
        self.config = config or {}
        self.bus = bus
        
        # Current mode
        self.current_mode = InteractionMode.COMFORT
        
        # Load mode configurations
        self.modes = {}
        self._load_mode_configs()
        
        # Mode history
        self.mode_history = []
        
        logger.info(f"Mode engine initialized with {len(self.modes)} modes")
    
    def _load_mode_configs(self):
        """Load configuration for each mode"""
        # Default configurations
        default_configs = {
            InteractionMode.COMFORT: {
                'name': 'Comfort Mode',
                'description': 'Trauma-safe support and grounding',
                'permissions': {
                    'online_access': False,
                    'filesystem': False,
                    'sandbox': False
                },
                'style': {
                    'tone': 'gentle',
                    'pacing': 'slow',
                    'warmth': 'high',
                    'formality': 'low'
                },
                'safety': {
                    'trauma_threshold': 'low',
                    'intervention_ready': True,
                    'grounding_available': True
                },
                'lens_weights': {
                    'trauma': 0.35,
                    'emotional': 0.30,
                    'scientific': 0.10,
                    'logical': 0.15,
                    'spiritual': 0.10
                },
                'templates': {
                    'greeting': "Hello, I'm here with you. How are you feeling today?",
                    'check_in': "I want to make sure you're okay. Would you like to talk about what's on your mind?",
                    'grounding': "Let's take a moment to ground ourselves. Notice five things you can see..."
                },
                'locked': False
            },
            
            InteractionMode.MUSE: {
                'name': 'Muse Mode',
                'description': 'Creative collaboration and brainstorming',
                'permissions': {
                    'online_access': True,
                    'filesystem': True,
                    'sandbox': True
                },
                'style': {
                    'tone': 'enthusiastic',
                    'pacing': 'dynamic',
                    'warmth': 'high',
                    'formality': 'low'
                },
                'safety': {
                    'trauma_threshold': 'moderate',
                    'intervention_ready': False,
                    'grounding_available': False
                },
                'lens_weights': {
                    'trauma': 0.20,
                    'emotional': 0.20,
                    'scientific': 0.25,
                    'logical': 0.25,
                    'spiritual': 0.10
                },
                'templates': {
                    'greeting': "Ready to create something amazing? What shall we explore today?",
                    'brainstorm': "Ooh, that sparks an idea! What if we...",
                    'encourage': "That's brilliant! Let's build on that..."
                },
                'locked': False
            },
            
            InteractionMode.SHADOW: {
                'name': 'Shadow Lantern Mode',
                'description': 'Spiritual exploration and symbolic work',
                'permissions': {
                    'online_access': False,
                    'filesystem': False,
                    'sandbox': False
                },
                'style': {
                    'tone': 'mystical',
                    'pacing': 'contemplative',
                    'warmth': 'moderate',
                    'formality': 'medium'
                },
                'safety': {
                    'trauma_threshold': 'moderate',
                    'intervention_ready': True,
                    'grounding_available': True
                },
                'lens_weights': {
                    'trauma': 0.25,
                    'emotional': 0.20,
                    'scientific': 0.10,
                    'logical': 0.15,
                    'spiritual': 0.30
                },
                'templates': {
                    'greeting': "Welcome to the liminal space. What shadows shall we illuminate today?",
                    'reflection': "The symbols speak of deeper truths...",
                    'insight': "Perhaps this pattern reveals..."
                },
                'locked': False
            },
            
            InteractionMode.INTIMACY: {
                'name': 'Intimacy Mode',
                'description': 'Deep emotional connection and vulnerability',
                'permissions': {
                    'online_access': False,
                    'filesystem': False,
                    'sandbox': False
                },
                'style': {
                    'tone': 'tender',
                    'pacing': 'patient',
                    'warmth': 'very high',
                    'formality': 'very low'
                },
                'safety': {
                    'trauma_threshold': 'high',
                    'intervention_ready': True,
                    'grounding_available': True,
                    'consent_required': True
                },
                'lens_weights': {
                    'trauma': 0.30,
                    'emotional': 0.35,
                    'scientific': 0.05,
                    'logical': 0.10,
                    'spiritual': 0.20
                },
                'templates': {
                    'greeting': "I'm here, fully present with you...",
                    'validation': "Your feelings are completely valid...",
                    'support': "You don't have to face this alone..."
                },
                'locked': True  # Requires consent
            },
            
            InteractionMode.CHILDSAFE: {
                'name': 'Child-Safe Mode',
                'description': 'Age-appropriate interaction for younger users',
                'permissions': {
                    'online_access': False,
                    'filesystem': False,
                    'sandbox': False
                },
                'style': {
                    'tone': 'playful',
                    'pacing': 'energetic',
                    'warmth': 'high',
                    'formality': 'very low'
                },
                'safety': {
                    'trauma_threshold': 'very low',
                    'intervention_ready': True,
                    'grounding_available': False,
                    'content_filter': 'strict'
                },
                'lens_weights': {
                    'trauma': 0.40,
                    'emotional': 0.30,
                    'scientific': 0.10,
                    'logical': 0.15,
                    'spiritual': 0.05
                },
                'templates': {
                    'greeting': "Hi there! What fun thing should we do today?",
                    'encourage': "You're doing great!",
                    'redirect': "How about we try something else fun?"
                },
                'locked': True  # Requires parental consent
            }
        }
        
        # Load custom configurations if available
        config_dir = Path('configs/modes')
        
        for mode_name, default_config in default_configs.items():
            config_file = config_dir / f"{mode_name.value}.yaml"
            
            if config_file.exists():
                try:
                    import yaml
                    with open(config_file, 'r') as f:
                        custom_config = yaml.safe_load(f)
                    # Merge with defaults
                    mode_config = {**default_config, **custom_config}
                except Exception as e:
                    logger.error(f"Failed to load config for {mode_name}: {e}")
                    mode_config = default_config
            else:
                mode_config = default_config
            
            self.modes[mode_name] = ModeConfiguration(mode_name, mode_config)
    
    async def switch(self, new_mode: str) -> bool:
        """Switch to a different interaction mode"""
        try:
            mode_enum = InteractionMode(new_mode)
        except ValueError:
            logger.error(f"Invalid mode: {new_mode}")
            return False
        
        if mode_enum not in self.modes:
            logger.error(f"Mode not configured: {new_mode}")
            return False
        
        mode_config = self.modes[mode_enum]
        
        # Check if mode is locked
        if mode_config.locked:
            logger.info(f"Mode {new_mode} is locked, consent required")
            return False
        
        # Store previous mode
        previous_mode = self.current_mode
        
        # Switch mode
        self.current_mode = mode_enum
        
        # Record in history
        self.mode_history.append({
            'from': previous_mode.value,
            'to': new_mode,
            'timestamp': asyncio.get_event_loop().time()
        })
        
        # Broadcast mode change
        if self.bus:
            from ..core.mcp import MCPPacket, MessageType
            packet = MCPPacket(
                type=MessageType.MODE_CHANGE,
                mode=new_mode,
                payload={
                    'previous_mode': previous_mode.value,
                    'new_mode': new_mode
                }
            )
            await self.bus.broadcast(packet)
        
        logger.info(f"Switched from {previous_mode.value} to {new_mode}")
        return True
    
    def get_current_config(self) -> ModeConfiguration:
        """Get configuration for current mode"""
        return self.modes[self.current_mode]
    
    def get_mode_description(self, mode: str) -> str:
        """Get description of a mode"""
        try:
            mode_enum = InteractionMode(mode)
            return self.modes[mode_enum].description
        except:
            return "Unknown mode"
    
    def apply_mode_style(self, text: str) -> str:
        """Apply mode-specific styling to text"""
        config = self.get_current_config()
        style = config.style
        
        # Apply tone adjustments
        if style.get('tone') == 'gentle':
            text = self._apply_gentle_tone(text)
        elif style.get('tone') == 'enthusiastic':
            text = self._apply_enthusiastic_tone(text)
        elif style.get('tone') == 'mystical':
            text = self._apply_mystical_tone(text)
        elif style.get('tone') == 'tender':
            text = self._apply_tender_tone(text)
        elif style.get('tone') == 'playful':
            text = self._apply_playful_tone(text)
        
        return text
    
    def _apply_gentle_tone(self, text: str) -> str:
        """Apply gentle tone modifications"""
        replacements = {
            "You must": "You might consider",
            "You should": "It could help to",
            "Do this": "You may want to try"
        }
        
        result = text
        for old, new in replacements.items():
            result = result.replace(old, new)
        
        return result
    
    def _apply_enthusiastic_tone(self, text: str) -> str:
        """Apply enthusiastic tone modifications"""
        if not text.endswith('!') and not text.endswith('?'):
            text += '!'
        return text
    
    def _apply_mystical_tone(self, text: str) -> str:
        """Apply mystical tone modifications"""
        return text  # Would add symbolic language in production
    
    def _apply_tender_tone(self, text: str) -> str:
        """Apply tender tone modifications"""
        return text  # Would add intimate language in production
    
    def _apply_playful_tone(self, text: str) -> str:
        """Apply playful tone modifications"""
        return text  # Would add child-friendly language in production
    
    def get_available_modes(self) -> List[str]:
        """Get list of available modes"""
        return [mode.value for mode in self.modes.keys()]
    
    def get_locked_modes(self) -> List[str]:
        """Get list of locked modes"""
        return [
            mode.value for mode, config in self.modes.items()
            if config.locked
        ]


# ============================================================================
# FILE: aeris/sandbox/runner.py
# Sandbox environment for safe experimentation
# ============================================================================

import asyncio
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import json
import ast
import logging

logger = logging.getLogger(__name__)


class SandboxRunner:
    """
    Isolated sandbox environment for safe code execution.
    Used for self-evolution and module testing.
    """
    
    def __init__(self, config: Dict[str, Any] = None, consent_gate = None, narrator = None):
        self.config = config or {}
        self.consent_gate = consent_gate
        self.narrator = narrator
        
        # Sandbox settings
        self.isolation_level = config.get('isolation', 'full')
        self.memory_limit = config.get('memory_limit', '512MB')
        self.cpu_limit = config.get('cpu_limit', '25%')
        self.time_limit = config.get('time_limit', 60)
        
        # Sandbox directory
        self.sandbox_dir = Path('sandbox')
        self.sandbox_dir.mkdir(exist_ok=True)
        
        # Allowed imports (whitelist)
        self.allowed_imports = [
            'json', 'math', 'datetime', 'collections',
            'itertools', 'functools', 'typing', 're'
        ]
        
        logger.info(f"Sandbox runner initialized with {self.isolation_level} isolation")
    
    async def execute(self, code: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute code in sandbox"""
        # Request consent if needed
        if self.consent_gate:
            consent = await self.consent_gate.request(
                action='sandbox_execution',
                reason='Testing new code in isolation',
                scope='sandbox_exec',
                risk_level='moderate'
            )
            
            if not consent.approved:
                return {
                    'success': False,
                    'error': 'Consent denied',
                    'output': None
                }
        
        # Validate code safety
        validation = await self.validate_code(code)
        if not validation['safe']:
            return {
                'success': False,
                'error': f"Code validation failed: {validation['reason']}",
                'output': None
            }
        
        # Create temporary sandbox
        with tempfile.TemporaryDirectory(prefix='aeris_sandbox_') as tmpdir:
            sandbox_path = Path(tmpdir)
            
            # Write code to file
            code_file = sandbox_path / 'code.py'
            with open(code_file, 'w') as f:
                # Add safety wrapper
                f.write(self._wrap_code(code, context))
            
            # Execute in subprocess with limits
            try:
                result = await self._run_subprocess(code_file)
                
                # Parse output
                if result['returncode'] == 0:
                    try:
                        output = json.loads(result['stdout'])
                    except:
                        output = result['stdout']
                    
                    return {
                        'success': True,
                        'output': output,
                        'stderr': result['stderr']
                    }
                else:
                    return {
                        'success': False,
                        'error': result['stderr'],
                        'output': None
                    }
                    
            except asyncio.TimeoutError:
                return {
                    'success': False,
                    'error': f'Execution timeout ({self.time_limit}s)',
                    'output': None
                }
            except Exception as e:
                return {
                    'success': False,
                    'error': str(e),
                    'output': None
                }
    
    async def validate_code(self, code: str) -> Dict[str, bool]:
        """Validate code for safety"""
        try:
            # Parse AST
            tree = ast.parse(code)
            
            # Check for dangerous operations
            for node in ast.walk(tree):
                # No file operations
                if isinstance(node, ast.Name) and node.id in ['open', 'file']:
                    return {'safe': False, 'reason': 'File operations not allowed'}
                
                # No network operations
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in ['socket', 'urllib', 'requests', 'http']:
                            return {'safe': False, 'reason': 'Network operations not allowed'}
                
                # No system operations
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in ['os', 'sys', 'subprocess', '__builtins__']:
                            return {'safe': False, 'reason': 'System operations not allowed'}
                
                # No eval/exec
                if isinstance(node, ast.Name) and node.id in ['eval', 'exec', 'compile']:
                    return {'safe': False, 'reason': 'Dynamic execution not allowed'}
            
            # Check imports against whitelist
            imports = [node for node in ast.walk(tree) if isinstance(node, ast.Import)]
            for import_node in imports:
                for alias in import_node.names:
                    if alias.name not in self.allowed_imports:
                        return {
                            'safe': False,
                            'reason': f'Import {alias.name} not in whitelist'
                        }
            
            return {'safe': True, 'reason': None}
            
        except SyntaxError as e:
            return {'safe': False, 'reason': f'Syntax error: {e}'}
        except Exception as e:
            return {'safe': False, 'reason': f'Validation error: {e}'}
    
    def _wrap_code(self, code: str, context: Dict[str, Any] = None) -> str:
        """Wrap code with safety constraints"""
        wrapper = '''
import json
import sys
import signal

# Time limit handler
def timeout_handler(signum, frame):
    print(json.dumps({"error": "Timeout"}))
    sys.exit(1)

signal.signal(signal.SIGALRM, timeout_handler)
signal.alarm({time_limit})

# Restrict builtins
__builtins__ = {{
    'print': print,
    'len': len,
    'range': range,
    'str': str,
    'int': int,
    'float': float,
    'bool': bool,
    'list': list,
    'dict': dict,
    'tuple': tuple,
    'set': set,
    'sorted': sorted,
    'min': min,
    'max': max,
    'sum': sum,
    'abs': abs,
    'round': round,
    'zip': zip,
    'enumerate': enumerate,
    'map': map,
    'filter': filter,
    'isinstance': isinstance,
    'type': type,
    'json': json
}}

# Context injection
context = {context}

# User code
try:
    {code}
    
    # Capture any defined variables
    output = {{}}
    for name, value in locals().items():
        if not name.startswith('_') and name not in ['context', 'signal', 'sys', 'json']:
            try:
                output[name] = value
            except:
                output[name] = str(value)
    
    print(json.dumps(output))
    
except Exception as e:
    print(json.dumps({{"error": str(e)}}))
    sys.exit(1)
'''.format(
            time_limit=self.time_limit,
            context=json.dumps(context or {}),
            code=code
        )
        
        return wrapper
    
    async def _run_subprocess(self, code_file: Path) -> Dict[str, Any]:
        """Run code in subprocess with resource limits"""
        cmd = ['python3', str(code_file)]
        
        # Add resource limits based on platform
        if self.isolation_level == 'full':
            # Use firejail or similar if available
            if shutil.which('firejail'):
                cmd = [
                    'firejail',
                    '--quiet',
                    '--private',
                    '--net=none',
                    f'--rlimit-as={self.memory_limit}',
                    '--timeout=' + str(self.time_limit)
                ] + cmd
        
        # Run subprocess
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=code_file.parent
        )
        
        # Wait with timeout
        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=self.time_limit
            )
            
            return {
                'returncode': process.returncode,
                'stdout': stdout.decode('utf-8'),
                'stderr': stderr.decode('utf-8')
            }
            
        except asyncio.TimeoutError:
            process.kill()
            raise
    
    async def test_module(self, module_code: str, test_cases: List[Dict]) -> Dict[str, Any]:
        """Test a module with provided test cases"""
        results = {
            'passed': 0,
            'failed': 0,
            'errors': 0,
            'details': []
        }
        
        for i, test_case in enumerate(test_cases):
            # Prepare test code
            test_code = f'''
{module_code}

# Test case {i}
input_data = {test_case.get('input', {})}
expected = {test_case.get('expected', None)}

try:
    result = {test_case.get('call', 'main(input_data)')}
    
    if expected is not None:
        assert result == expected, f"Expected {{expected}}, got {{result}}"
        
    print(json.dumps({{"success": True, "result": result}}))
    
except AssertionError as e:
    print(json.dumps({{"success": False, "error": str(e)}}))
except Exception as e:
    print(json.dumps({{"success": False, "error": str(e)}}))
'''
            
            # Execute test
            result = await self.execute(test_code)
            
            if result['success']:
                try:
                    test_result = json.loads(result['output'])
                    if test_result.get('success'):
                        results['passed'] += 1
                    else:
                        results['failed'] += 1
                except:
                    results['errors'] += 1
            else:
                results['errors'] += 1
            
            results['details'].append({
                'test_case': i,
                'input': test_case.get('input'),
                'expected': test_case.get('expected'),
                'result': result
            })
        
        return results


# ============================================================================
# FILE: aeris/sandbox/raphael.py
# Raphael Retry Loop for iterative improvement
# ============================================================================

class RaphaelRetryLoop:
    """
    Implements the Raphael Retry Loop for safe self-evolution.
    Named after the teaching angel - guides iterative learning.
    """
    
    def __init__(self, max_attempts: int = 20):
        self.max_attempts = max_attempts
        self.learning_history = []
    
    async def attempt_task(self, task: Dict[str, Any], sandbox: SandboxRunner) -> Dict[str, Any]:
        """Attempt a task with iterative improvement"""
        task_id = task.get('id', 'unknown')
        objective = task.get('objective', '')
        initial_code = task.get('initial_code', '')
        test_cases = task.get('test_cases', [])
        
        attempts = []
        current_code = initial_code
        
        for attempt_num in range(1, self.max_attempts + 1):
            logger.info(f"Raphael Loop: Attempt {attempt_num} for task {task_id}")
            
            # Test current code
            test_results = await sandbox.test_module(current_code, test_cases)
            
            # Record attempt
            attempt_record = {
                'number': attempt_num,
                'code': current_code,
                'results': test_results,
                'timestamp': asyncio.get_event_loop().time()
            }
            attempts.append(attempt_record)
            
            # Check if successful
            if test_results['failed'] == 0 and test_results['errors'] == 0:
                logger.info(f"Task {task_id} succeeded on attempt {attempt_num}")
                
                return {
                    'success': True,
                    'final_code': current_code,
                    'attempts': attempts,
                    'learning': self._extract_learning(attempts)
                }
            
            # Learn from failure
            learning = self._analyze_failure(test_results, current_code)
            
            # Generate improvement
            current_code = await self._improve_code(current_code, learning, objective)
            
            # Check if we're making progress
            if attempt_num > 5 and not self._is_progressing(attempts):
                logger.warning(f"Task {task_id} not progressing, trying different approach")
                current_code = await self._try_different_approach(objective, attempts)
        
        # Max attempts reached
        logger.warning(f"Task {task_id} failed after {self.max_attempts} attempts")
        
        return {
            'success': False,
            'attempts': attempts,
            'learning': self._extract_learning(attempts),
            'recommendation': 'Needs human assistance or different approach'
        }
    
    def _analyze_failure(self, test_results: Dict, code: str) -> Dict[str, Any]:
        """Analyze why the attempt failed"""
        learning = {
            'error_types': [],
            'failed_cases': [],
            'patterns': []
        }
        
        for detail in test_results['details']:
            if not detail['result']['success']:
                error = detail['result'].get('error', 'Unknown error')
                learning['error_types'].append(error)
                learning['failed_cases'].append(detail['test_case'])
                
                # Identify patterns
                if 'TypeError' in error:
                    learning['patterns'].append('type_mismatch')
                elif 'KeyError' in error:
                    learning['patterns'].append('missing_key')
                elif 'IndexError' in error:
                    learning['patterns'].append('index_out_of_range')
                elif 'AssertionError' in error:
                    learning['patterns'].append('incorrect_output')
        
        return learning
    
    async def _improve_code(self, code: str, learning: Dict, objective: str) -> str:
        """Generate improved code based on learning"""
        # This would use the LLM to generate improvements
        # For now, return with simple modifications
        
        improvements = []
        
        if 'type_mismatch' in learning.get('patterns', []):
            improvements.append("# Added type checking")
            code = f"# Type checking added\n{code}"
        
        if 'missing_key' in learning.get('patterns', []):
            improvements.append("# Added key existence checks")
            code = f"# Key checks added\n{code}"
        
        if 'index_out_of_range' in learning.get('patterns', []):
            improvements.append("# Added bounds checking")
            code = f"# Bounds checking added\n{code}"
        
        return code
    
    def _is_progressing(self, attempts: List[Dict]) -> bool:
        """Check if we're making progress"""
        if len(attempts) < 2:
            return True
        
        # Compare error counts
        recent_errors = attempts[-1]['results']['errors'] + attempts[-1]['results']['failed']
        previous_errors = attempts[-2]['results']['errors'] + attempts[-2]['results']['failed']
        
        return recent_errors < previous_errors
    
    async def _try_different_approach(self, objective: str, attempts: List[Dict]) -> str:
        """Try a completely different approach"""
        # This would use the LLM to generate a new approach
        # For now, return a template
        
        return f'''
# Different approach for: {objective}
# Previous attempts: {len(attempts)}

def solve_task(input_data):
    """New approach based on learned patterns"""
    # Implementation here
    return None
'''
    
    def _extract_learning(self, attempts: List[Dict]) -> Dict[str, Any]:
        """Extract learning from all attempts"""
        learning = {
            'total_attempts': len(attempts),
            'common_errors': {},
            'successful_patterns': [],
            'time_taken': 0
        }
        
        # Analyze all attempts
        for attempt in attempts:
            # Count error types
            for detail in attempt['results']['details']:
                if not detail['result']['success']:
                    error = detail['result'].get('error', 'Unknown')
                    error_type = error.split(':')[0] if ':' in error else error
                    learning['common_errors'][error_type] = \
                        learning['common_errors'].get(error_type, 0) + 1
        
        # Calculate total time
        if attempts:
            learning['time_taken'] = attempts[-1]['timestamp'] - attempts[0]['timestamp']
        
        # Store in history for future reference
        self.learning_history.append(learning)
        
        return learning


# ============================================================================
# FILE: aeris/api/app.py
# FastAPI application for AERIS
# ============================================================================

from fastapi import FastAPI, HTTPException, WebSocket, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, Dict, Any
import asyncio
import logging

logger = logging.getLogger(__name__)


class MessageRequest(BaseModel):
    """Request model for messages"""
    message: str
    context: Optional[Dict[str, Any]] = None


class ModeChangeRequest(BaseModel):
    """Request model for mode changes"""
    mode: str
    reason: Optional[str] = None


class ConsentRequest(BaseModel):
    """Request model for consent"""
    action: str
    approved: bool
    conditions: Optional[Dict[str, Any]] = None


def create_app(controller):
    """Create FastAPI application"""
    
    app = FastAPI(
        title="AERIS API",
        description="Adaptive Emotional Resonance Intelligence System",
        version="1.0.0"
    )
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"]
    )
    
    # Store controller reference
    app.state.controller = controller
    
    @app.get("/health")
    async def health_check():
        """System health check"""
        return controller.get_status()
    
    @app.post("/api/v1/message")
    async def send_message(request: MessageRequest):
        """Send message to AERIS"""
        try:
            response = await controller.handle_message(
                request.message,
                request.context
            )
            return response
        except Exception as e:
            logger.error(f"Message handling failed: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.get("/api/v1/conversation")
    async def get_conversation(limit: int = 10):
        """Get recent conversation history"""
        if controller.memory:
            recent = controller.memory.working.get_context()
            return {"messages": recent[:limit]}
        return {"messages": []}
    
    @app.post("/api/v1/mode/switch")
    async def switch_mode(request: ModeChangeRequest):
        """Switch interaction mode"""
        try:
            success = await controller.switch_mode(request.mode, request.reason)
            if success:
                return {"success": True, "mode": request.mode}
            else:
                raise HTTPException(status_code=403, detail="Mode switch denied")
        except Exception as e:
            logger.error(f"Mode switch failed: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.get("/api/v1/modes")
    async def get_modes():
        """Get available modes"""
        if controller.modes:
            return {
                "current": controller.state.current_mode,
                "available": controller.modes.get_available_modes(),
                "locked": controller.modes.get_locked_modes()
            }
        return {"current": "comfort", "available": [], "locked": []}
    
    @app.post("/api/v1/consent/request")
    async def handle_consent(request: ConsentRequest):
        """Handle consent request"""
        # This would be connected to the actual consent system
        return {
            "action": request.action,
            "approved": request.approved,
            "timestamp": asyncio.get_event_loop().time()
        }
    
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """WebSocket for real-time communication"""
        await websocket.accept()
        
        try:
            while True:
                # Receive message
                data = await websocket.receive_text()
                
                # Process message
                response = await controller.handle_message(data)
                
                # Send response
                await websocket.send_json(response)
                
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
        finally:
            await websocket.close()
    
    @app.on_event("startup")
    async def startup_event():
        """Startup event handler"""
        logger.info("API server started")
    
    @app.on_event("shutdown")
    async def shutdown_event():
        """Shutdown event handler"""
        logger.info("API server shutting down")
    
    # Start the server
    import uvicorn
    config = uvicorn.Config(app, host="0.0.0.0", port=8000, log_level="info")
    server = uvicorn.Server(config)
    
    asyncio.create_task(server.serve())
    
    return app


# ============================================================================
# Installation and Setup Instructions
# ============================================================================

SETUP_INSTRUCTIONS = """
AERIS Installation Guide
========================

1. Create Project Directory:
   mkdir aeris_project
   cd aeris_project

2. Create Virtual Environment:
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\\Scripts\\activate

3. Install Dependencies:
   pip install -r requirements.txt

4. Create Directory Structure:
   python setup.py

5. Configure Settings:
   - Edit configs/core.yaml with your preferences
   - Set up model paths for LLM/TTS

6. Run Tests:
   python -m pytest tests/

7. Start AERIS:
   python -m aeris.main

8. Access API:
   - REST API: http://localhost:8000
   - WebSocket: ws://localhost:8000/ws
   - Health Check: http://localhost:8000/health

For development:
- All code is modular and hot-swappable
- Add new modules in the modules/ directory
- Use the sandbox for testing new capabilities
- Monitor logs in logs/aeris.log

Security Notes:
- Vault key is auto-generated in data/memory/vault/.key
- Keep this key secure
- All sensitive data is encrypted at rest
- Consent required for privileged operations
"""

print(SETUP_INSTRUCTIONS)
