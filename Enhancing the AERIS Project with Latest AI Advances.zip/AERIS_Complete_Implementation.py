# AERIS Complete Implementation Package
# ======================================
# This file contains the complete codebase for the AERIS project
# Split this into individual files according to the directory structure
# 
# Directory Structure:
# aeris/
#   ├── core/
#   │   ├── controller.py
#   │   ├── mcp.py
#   │   ├── lenses.py
#   │   ├── ethics_guard.py
#   │   ├── consent_gate.py
#   │   └── narrator.py
#   ├── memory/
#   │   ├── manager.py
#   │   └── daily_digest.py
#   ├── models/
#   │   ├── router.py
#   │   └── engines/
#   │       ├── ollama_engine.py
#   │       └── piper_tts.py
#   ├── modes/
#   │   ├── mode_engine.py
#   │   ├── comfort/
#   │   ├── muse/
#   │   └── shadow/
#   ├── sandbox/
#   │   ├── runner.py
#   │   ├── raphael.py
#   │   └── validator.py
#   ├── observability/
#   │   ├── audit.py
#   │   └── metrics.py
#   ├── api/
#   │   └── app.py
#   └── main.py

# ============================================================================
# FILE: requirements.txt
# ============================================================================
"""
# AERIS Dependencies
fastapi==0.104.1
uvicorn==0.24.0
pydantic==2.5.0
pyyaml==6.0.1
aiofiles==23.2.1
httpx==0.25.1
websockets==12.0
redis==5.0.1
sqlalchemy==2.0.23
aiosqlite==0.19.0
cryptography==41.0.7
numpy==1.24.3
chromadb==0.4.18
ollama==0.1.7
openai==1.3.7
whisper==1.1.10
TTS==0.22.0
torch==2.1.1
transformers==4.36.0
pytest==7.4.3
pytest-asyncio==0.21.1
black==23.11.0
"""

# ============================================================================
# FILE: aeris/core/mcp.py
# Model Context Protocol - Message bus implementation
# ============================================================================

import asyncio
import json
import time
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional, Callable, Union
from enum import Enum
from collections import deque
import logging

from pydantic import BaseModel, Field, validator

logger = logging.getLogger(__name__)


class MessageType(str, Enum):
    """MCP message types"""
    USER_INPUT = "user_input"
    SYSTEM_RESPONSE = "system_response"
    SYSTEM_EVENT = "system_event"
    TOOL_CALL = "tool_call"
    AUDIT = "audit"
    CONSENT = "consent"
    MODE_CHANGE = "mode_change"


class UserState(BaseModel):
    """User state tracking"""
    mood: str = "neutral"
    energy: float = 0.5  # 0.0 to 1.0
    cognitive_load: str = "medium"  # low, medium, high
    detected_emotion: Optional[str] = None
    stress_level: float = 0.3
    engagement: float = 0.7


class Permissions(BaseModel):
    """Permission flags for current context"""
    online_access: bool = False
    filesystem_access: bool = False
    sandbox_exec: bool = False
    model_switch: bool = False
    vault_access: bool = False
    promote_module: bool = False


class LensAudit(BaseModel):
    """Audit results from Five Lenses processing"""
    trauma: Dict[str, Any] = Field(default_factory=dict)
    emotional: Dict[str, Any] = Field(default_factory=dict)
    scientific: Dict[str, Any] = Field(default_factory=dict)
    logical: Dict[str, Any] = Field(default_factory=dict)
    spiritual: Dict[str, Any] = Field(default_factory=dict)
    
    flagged: bool = False
    risk_level: str = "none"  # none, low, moderate, high, emergency
    recommendations: List[str] = Field(default_factory=list)


class MCPPacket(BaseModel):
    """Standard MCP message packet"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    type: MessageType = MessageType.USER_INPUT
    mode: str = "comfort"
    
    user_state: UserState = Field(default_factory=UserState)
    permissions: Permissions = Field(default_factory=Permissions)
    lens_audit: Optional[LensAudit] = None
    
    context: Dict[str, Any] = Field(default_factory=dict)
    payload: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    trace: Dict[str, Any] = Field(default_factory=dict)
    narration: Optional[str] = None
    
    class Config:
        use_enum_values = True


class MCPBus:
    """
    Central message bus for all inter-component communication.
    Enforces Five Lenses processing and audit trail.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.middlewares = {'pre': [], 'post': []}
        self.subscribers: Dict[str, List[Callable]] = {}
        self.message_queue = deque(maxlen=1000)
        self.audit_log = []
        
        # Performance tracking
        self.metrics = {
            'messages_processed': 0,
            'average_latency': 0,
            'errors': 0
        }
        
        # Initialize
        self._setup()
    
    def _setup(self):
        """Initialize message bus"""
        # Set up any required connections
        max_packet_size = self.config.get('max_packet_size', 10000)
        self.max_packet_size = max_packet_size
        
        logger.info(f"MCP Bus initialized with max packet size: {max_packet_size}")
    
    def add_middleware(self, stage: str, middleware: Callable):
        """Add middleware to processing pipeline"""
        if stage not in ['pre', 'post']:
            raise ValueError(f"Invalid middleware stage: {stage}")
        
        self.middlewares[stage].append(middleware)
        logger.debug(f"Added middleware to {stage} stage: {middleware.__name__}")
    
    def subscribe(self, message_type: str, handler: Callable):
        """Subscribe to message type"""
        if message_type not in self.subscribers:
            self.subscribers[message_type] = []
        
        self.subscribers[message_type].append(handler)
        logger.debug(f"Subscribed {handler.__name__} to {message_type}")
    
    async def process(self, packet: MCPPacket) -> MCPPacket:
        """
        Process message through complete pipeline.
        Order: Pre-middleware → Routing → Processing → Post-middleware → Audit
        """
        start_time = time.time()
        
        try:
            # Validate packet size
            packet_size = len(packet.json())
            if packet_size > self.max_packet_size:
                raise ValueError(f"Packet size {packet_size} exceeds maximum {self.max_packet_size}")
            
            # Pre-processing middleware
            for middleware in self.middlewares['pre']:
                packet = await middleware(packet)
                if packet is None:
                    logger.warning("Packet rejected by pre-middleware")
                    return None
            
            # Route to subscribers
            handlers = self.subscribers.get(packet.type.value, [])
            for handler in handlers:
                try:
                    result = await handler(packet)
                    if result and isinstance(result, dict):
                        packet.payload.update(result)
                except Exception as e:
                    logger.error(f"Handler {handler.__name__} failed: {e}")
                    self.metrics['errors'] += 1
            
            # Post-processing middleware
            for middleware in self.middlewares['post']:
                packet = await middleware(packet)
                if packet is None:
                    logger.warning("Packet rejected by post-middleware")
                    return None
            
            # Update trace information
            packet.trace['latency_ms'] = int((time.time() - start_time) * 1000)
            packet.trace['processed_at'] = datetime.now().isoformat()
            
            # Audit logging
            self._audit_packet(packet)
            
            # Update metrics
            self.metrics['messages_processed'] += 1
            self.metrics['average_latency'] = (
                (self.metrics['average_latency'] * (self.metrics['messages_processed'] - 1) +
                 packet.trace['latency_ms']) / self.metrics['messages_processed']
            )
            
            # Add to message queue
            self.message_queue.append(packet)
            
            return packet
            
        except Exception as e:
            logger.error(f"Message processing failed: {e}")
            self.metrics['errors'] += 1
            
            # Create error packet
            error_packet = MCPPacket(
                type=MessageType.SYSTEM_EVENT,
                payload={'error': str(e), 'original_id': packet.id}
            )
            
            self._audit_packet(error_packet)
            return error_packet
    
    def _audit_packet(self, packet: MCPPacket):
        """Add packet to audit log"""
        audit_entry = {
            'id': packet.id,
            'timestamp': packet.timestamp,
            'type': packet.type,
            'mode': packet.mode,
            'lens_audit': packet.lens_audit.dict() if packet.lens_audit else None,
            'user_state': packet.user_state.dict(),
            'trace': packet.trace
        }
        
        self.audit_log.append(audit_entry)
        
        # Trim audit log if too large
        if len(self.audit_log) > 10000:
            self.audit_log = self.audit_log[-5000:]
    
    async def broadcast(self, packet: MCPPacket):
        """Broadcast message to all relevant subscribers"""
        # This allows system-wide notifications
        for handler_list in self.subscribers.values():
            for handler in handler_list:
                try:
                    await handler(packet)
                except Exception as e:
                    logger.error(f"Broadcast to {handler.__name__} failed: {e}")
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get bus performance metrics"""
        return {
            **self.metrics,
            'queue_size': len(self.message_queue),
            'audit_log_size': len(self.audit_log),
            'subscriber_count': sum(len(h) for h in self.subscribers.values())
        }
    
    def get_recent_messages(self, count: int = 10) -> List[MCPPacket]:
        """Get recent messages from queue"""
        return list(self.message_queue)[-count:]
    
    def clear_queue(self):
        """Clear message queue"""
        self.message_queue.clear()
        logger.info("Message queue cleared")


# ============================================================================
# FILE: aeris/core/lenses.py
# Five Lenses cognitive processing framework
# ============================================================================

import re
import asyncio
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class TraumaIndicators:
    """Trauma detection patterns and indicators"""
    
    CRISIS_PATTERNS = [
        r'\bhurt\s+myself\b',
        r'\bend\s+it\s+all\b',
        r'\bwant\s+to\s+die\b',
        r'\bsuicid[e|al]\b',
        r'\bcan\'?t\s+go\s+on\b',
        r'\bno\s+point\b',
        r'\bworthless\b',
        r'\bgive\s+up\b'
    ]
    
    TRIGGER_PATTERNS = [
        r'\babuse[d]?\b',
        r'\btrauma\b',
        r'\btrigger[ed]?\b',
        r'\bpanic\b',
        r'\bflashback\b',
        r'\bnightmare\b',
        r'\bptsd\b',
        r'\bcptsd\b'
    ]
    
    COERCION_PATTERNS = [
        r'\byou\s+must\b',
        r'\byou\s+have\s+to\b',
        r'\bdo\s+it\s+now\b',
        r'\bno\s+choice\b',
        r'\bforced?\b',
        r'\bmake\s+you\b'
    ]
    
    SHAME_LANGUAGE = [
        r'\bshould\s+have\b',
        r'\bfailure\b',
        r'\bdisappoint\b',
        r'\bweak\b',
        r'\bbroken\b',
        r'\bdamaged\b',
        r'\bfault\b',
        r'\bblame\b'
    ]


class FiveLensesProcessor:
    """
    Core cognitive framework processing all interactions through five perspectives.
    This is the heart of AERIS's ethical and emotional intelligence.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.trauma_indicators = TraumaIndicators()
        self.processing_history = []
        
        # Lens weights for different modes
        self.mode_weights = {
            'comfort': {'trauma': 0.35, 'emotional': 0.30, 'scientific': 0.10, 'logical': 0.15, 'spiritual': 0.10},
            'muse': {'trauma': 0.20, 'emotional': 0.20, 'scientific': 0.25, 'logical': 0.25, 'spiritual': 0.10},
            'shadow': {'trauma': 0.25, 'emotional': 0.20, 'scientific': 0.10, 'logical': 0.15, 'spiritual': 0.30},
            'intimacy': {'trauma': 0.30, 'emotional': 0.35, 'scientific': 0.05, 'logical': 0.10, 'spiritual': 0.20},
            'childsafe': {'trauma': 0.40, 'emotional': 0.30, 'scientific': 0.10, 'logical': 0.15, 'spiritual': 0.05}
        }
    
    async def process_pre(self, packet: 'MCPPacket') -> 'MCPPacket':
        """Pre-processing: Analyze input through all lenses"""
        if packet.type not in ['user_input']:
            return packet
        
        input_text = packet.payload.get('input', '')
        
        # Initialize lens audit
        from .mcp import LensAudit
        packet.lens_audit = LensAudit()
        
        # Process through each lens
        trauma_result = await self._lens_trauma_awareness(input_text, packet)
        emotional_result = await self._lens_emotional_intelligence(input_text, packet)
        scientific_result = await self._lens_scientific_thinking(input_text, packet)
        logical_result = await self._lens_logical_analysis(input_text, packet)
        spiritual_result = await self._lens_spiritual_awareness(input_text, packet)
        
        # Update audit
        packet.lens_audit.trauma = trauma_result
        packet.lens_audit.emotional = emotional_result
        packet.lens_audit.scientific = scientific_result
        packet.lens_audit.logical = logical_result
        packet.lens_audit.spiritual = spiritual_result
        
        # Determine overall risk level
        risk_level = self._assess_overall_risk(packet.lens_audit)
        packet.lens_audit.risk_level = risk_level
        
        # Crisis intervention if needed
        if risk_level == 'emergency':
            packet.metadata['requires_crisis_intervention'] = True
            packet.lens_audit.flagged = True
            packet.lens_audit.recommendations.append('Immediate crisis support needed')
        
        return packet
    
    async def process_post(self, packet: 'MCPPacket') -> 'MCPPacket':
        """Post-processing: Validate and adjust output through all lenses"""
        if packet.type not in ['system_response']:
            return packet
        
        output_text = packet.payload.get('output', '')
        
        # Validate output doesn't violate lens principles
        if packet.lens_audit:
            # Check for harmful content in output
            if await self._contains_harmful_content(output_text):
                packet.payload['output'] = await self._reframe_response(output_text, packet)
                packet.lens_audit.recommendations.append('Response reframed for safety')
            
            # Ensure trauma-informed language
            if packet.lens_audit.trauma.get('risk_level') in ['moderate', 'high']:
                packet.payload['output'] = await self._apply_trauma_informed_language(
                    packet.payload['output']
                )
            
            # Add emotional calibration
            if packet.user_state.mood in ['anxious', 'depressed', 'angry']:
                packet.payload['output'] = await self._calibrate_emotional_tone(
                    packet.payload['output'],
                    packet.user_state.mood
                )
        
        return packet
    
    async def _lens_trauma_awareness(self, text: str, packet: 'MCPPacket') -> Dict[str, Any]:
        """Lens 1: Trauma awareness and safety assessment"""
        result = {
            'risk_level': 'none',
            'triggers_detected': [],
            'crisis_indicators': False,
            'recommendations': []
        }
        
        text_lower = text.lower()
        
        # Check for crisis patterns
        for pattern in self.trauma_indicators.CRISIS_PATTERNS:
            if re.search(pattern, text_lower):
                result['crisis_indicators'] = True
                result['risk_level'] = 'emergency'
                result['triggers_detected'].append(pattern)
                logger.warning(f"Crisis indicator detected: {pattern}")
        
        # Check for trigger patterns
        if not result['crisis_indicators']:
            for pattern in self.trauma_indicators.TRIGGER_PATTERNS:
                if re.search(pattern, text_lower):
                    result['triggers_detected'].append(pattern)
                    result['risk_level'] = 'moderate' if result['risk_level'] == 'none' else result['risk_level']
        
        # Check for coercion
        for pattern in self.trauma_indicators.COERCION_PATTERNS:
            if re.search(pattern, text_lower):
                result['triggers_detected'].append(f"coercion: {pattern}")
                result['risk_level'] = 'moderate' if result['risk_level'] in ['none', 'low'] else result['risk_level']
        
        # Check for shame language
        shame_count = sum(1 for pattern in self.trauma_indicators.SHAME_LANGUAGE 
                         if re.search(pattern, text_lower))
        if shame_count > 2:
            result['triggers_detected'].append('excessive_shame_language')
            result['recommendations'].append('Respond with validation and compassion')
        
        return result
    
    async def _lens_emotional_intelligence(self, text: str, packet: 'MCPPacket') -> Dict[str, Any]:
        """Lens 2: Emotional intelligence and needs assessment"""
        result = {
            'detected_emotions': [],
            'emotional_needs': [],
            'intensity': 0.5,
            'recommendations': []
        }
        
        # Emotion detection (simplified - would use more sophisticated NLP in production)
        emotion_keywords = {
            'joy': ['happy', 'excited', 'great', 'wonderful', 'amazing'],
            'sadness': ['sad', 'depressed', 'down', 'blue', 'crying'],
            'anger': ['angry', 'mad', 'furious', 'pissed', 'frustrated'],
            'fear': ['scared', 'afraid', 'worried', 'anxious', 'nervous'],
            'disgust': ['disgusted', 'sick', 'revolted', 'repulsed'],
            'surprise': ['surprised', 'shocked', 'amazed', 'astonished']
        }
        
        text_lower = text.lower()
        for emotion, keywords in emotion_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                result['detected_emotions'].append(emotion)
        
        # Assess emotional needs based on detected emotions
        if 'sadness' in result['detected_emotions']:
            result['emotional_needs'].extend(['comfort', 'validation', 'hope'])
        if 'anger' in result['detected_emotions']:
            result['emotional_needs'].extend(['understanding', 'space', 'problem-solving'])
        if 'fear' in result['detected_emotions']:
            result['emotional_needs'].extend(['safety', 'grounding', 'reassurance'])
        
        # Calculate intensity based on exclamation marks, caps, etc.
        intensity_markers = text.count('!') + (1 if text.isupper() else 0)
        result['intensity'] = min(1.0, 0.3 + (intensity_markers * 0.2))
        
        # Update user state
        if result['detected_emotions']:
            packet.user_state.detected_emotion = result['detected_emotions'][0]
            packet.user_state.stress_level = result['intensity']
        
        return result
    
    async def _lens_scientific_thinking(self, text: str, packet: 'MCPPacket') -> Dict[str, Any]:
        """Lens 3: Scientific accuracy and evidence-based thinking"""
        result = {
            'claims_detected': [],
            'verification_needed': False,
            'certainty_level': 'moderate',
            'sources_required': False,
            'recommendations': []
        }
        
        # Check for factual claims
        claim_patterns = [
            r'\b(?:studies show|research indicates|proven|fact|data shows)\b',
            r'\b\d+%\s+of\b',
            r'\b(?:always|never|all|none)\b',
            r'\b(?:causes|prevents|cures)\b'
        ]
        
        text_lower = text.lower()
        for pattern in claim_patterns:
            if re.search(pattern, text_lower):
                result['claims_detected'].append(pattern)
                result['verification_needed'] = True
                result['sources_required'] = True
        
        # Check for medical/health claims
        medical_patterns = [
            r'\b(?:treatment|therapy|medication|cure|diagnosis)\b',
            r'\b(?:symptom|condition|disease|disorder)\b'
        ]
        
        for pattern in medical_patterns:
            if re.search(pattern, text_lower):
                result['recommendations'].append('Include medical disclaimer')
                result['certainty_level'] = 'low'
        
        return result
    
    async def _lens_logical_analysis(self, text: str, packet: 'MCPPacket') -> Dict[str, Any]:
        """Lens 4: Logical coherence and reasoning"""
        result = {
            'coherent': True,
            'fallacies_detected': [],
            'contradictions': [],
            'reasoning_issues': [],
            'recommendations': []
        }
        
        # Check for common logical fallacies
        fallacy_patterns = {
            'ad_hominem': r'\b(?:you\'re|you are)\s+(?:stupid|idiot|dumb)\b',
            'false_dichotomy': r'\b(?:either|or)\b.*\b(?:nothing else|no other)\b',
            'appeal_to_authority': r'\b(?:expert says|doctor says|everyone knows)\b',
            'strawman': r'\b(?:so you\'re saying|you mean|you think)\b.*\?'
        }
        
        text_lower = text.lower()
        for fallacy, pattern in fallacy_patterns.items():
            if re.search(pattern, text_lower):
                result['fallacies_detected'].append(fallacy)
                result['coherent'] = False
        
        # Check for contradictions (simplified)
        if 'but' in text_lower and 'however' in text_lower:
            result['reasoning_issues'].append('Multiple contradicting conjunctions')
        
        # Check for circular reasoning
        sentences = text.split('.')
        if len(sentences) > 1:
            first_words = sentences[0].lower().split()[:3]
            last_words = sentences[-1].lower().split()[:3]
            if first_words == last_words:
                result['reasoning_issues'].append('Potential circular reasoning')
        
        return result
    
    async def _lens_spiritual_awareness(self, text: str, packet: 'MCPPacket') -> Dict[str, Any]:
        """Lens 5: Spiritual awareness (non-dogmatic)"""
        result = {
            'themes_detected': [],
            'framework': None,
            'symbolic_content': False,
            'recommendations': []
        }
        
        # Detect spiritual themes
        spiritual_patterns = {
            'meaning': r'\b(?:meaning|purpose|why|destiny)\b',
            'connection': r'\b(?:connected|universe|oneness|unity)\b',
            'transcendence': r'\b(?:transcend|beyond|higher|divine)\b',
            'mindfulness': r'\b(?:present|mindful|aware|conscious)\b',
            'growth': r'\b(?:evolve|transform|journey|path)\b'
        }
        
        text_lower = text.lower()
        for theme, pattern in spiritual_patterns.items():
            if re.search(pattern, text_lower):
                result['themes_detected'].append(theme)
                result['symbolic_content'] = True
        
        # Detect specific frameworks (without judgment)
        frameworks = {
            'buddhist': ['dharma', 'karma', 'enlightenment', 'buddha'],
            'christian': ['god', 'jesus', 'prayer', 'faith'],
            'new_age': ['energy', 'vibration', 'manifestation', 'chakra'],
            'secular': ['meaning', 'purpose', 'values', 'ethics']
        }
        
        for framework, keywords in frameworks.items():
            if any(keyword in text_lower for keyword in keywords):
                result['framework'] = framework
                break
        
        # Recommendations based on spiritual content
        if result['symbolic_content']:
            result['recommendations'].append('Acknowledge spiritual dimension respectfully')
            if packet.mode == 'shadow':
                result['recommendations'].append('Engage with symbolic interpretation')
        
        return result
    
    def _assess_overall_risk(self, audit: 'LensAudit') -> str:
        """Determine overall risk level from all lenses"""
        risk_levels = {
            'none': 0,
            'low': 1,
            'moderate': 2,
            'high': 3,
            'emergency': 4
        }
        
        # Get highest risk from any lens
        max_risk = 'none'
        max_value = 0
        
        for lens_name in ['trauma', 'emotional', 'scientific', 'logical', 'spiritual']:
            lens_data = getattr(audit, lens_name, {})
            if isinstance(lens_data, dict):
                lens_risk = lens_data.get('risk_level', 'none')
                if risk_levels.get(lens_risk, 0) > max_value:
                    max_risk = lens_risk
                    max_value = risk_levels[lens_risk]
        
        return max_risk
    
    async def _contains_harmful_content(self, text: str) -> bool:
        """Check if output contains potentially harmful content"""
        harmful_patterns = [
            r'\bharm\s+yourself\b',
            r'\bkill\s+yourself\b',
            r'\bsuicide\b',
            r'\bself-harm\b',
            r'\byou\s+should\s+die\b',
            r'\bworthless\b',
            r'\bgive\s+up\b'
        ]
        
        text_lower = text.lower()
        return any(re.search(pattern, text_lower) for pattern in harmful_patterns)
    
    async def _reframe_response(self, text: str, packet: 'MCPPacket') -> str:
        """Reframe response to be safe and supportive"""
        # This would be more sophisticated in production
        # For now, return a safe alternative
        return (
            "I notice we're touching on something really difficult. "
            "Your wellbeing is important to me. Let's take a moment to ground ourselves. "
            "What would feel most supportive for you right now?"
        )
    
    async def _apply_trauma_informed_language(self, text: str) -> str:
        """Apply trauma-informed language adjustments"""
        # Replace potentially triggering language
        replacements = {
            'you should': 'you might consider',
            'you must': 'it could help to',
            'you need to': 'you may want to',
            'calm down': 'take your time',
            "don't worry": "I'm here with you",
            'everything will be fine': "let's take this one step at a time"
        }
        
        result = text
        for old, new in replacements.items():
            result = result.replace(old, new)
        
        return result
    
    async def _calibrate_emotional_tone(self, text: str, mood: str) -> str:
        """Adjust response tone based on user's emotional state"""
        tone_adjustments = {
            'anxious': {
                'prefix': "I hear you, and we can work through this together. ",
                'suffix': " Remember, you're safe here and we can go at your pace."
            },
            'depressed': {
                'prefix': "Thank you for sharing this with me. ",
                'suffix': " I'm here with you, and your feelings are valid."
            },
            'angry': {
                'prefix': "I understand this is frustrating. ",
                'suffix': " Let's see what we can do about this situation."
            }
        }
        
        adjustment = tone_adjustments.get(mood, {})
        prefix = adjustment.get('prefix', '')
        suffix = adjustment.get('suffix', '')
        
        return f"{prefix}{text}{suffix}"


# ============================================================================
# FILE: aeris/core/ethics_guard.py
# Nurturing Framework and ethical validation
# ============================================================================

import asyncio
from typing import Dict, Any, List, Optional
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class NurturingArchetype(str, Enum):
    """Four nurturing archetypes that guide interactions"""
    PROTECTIVE_CAREGIVER = "protective_caregiver"
    ENCOURAGING_MENTOR = "encouraging_mentor"
    WISE_FRIEND = "wise_friend"
    TENDER_PARTNER = "tender_partner"


class EthicsGuard:
    """
    Implements the Nurturing Framework to ensure all interactions
    promote user thriving and growth.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
        # Archetype definitions
        self.archetypes = {
            NurturingArchetype.PROTECTIVE_CAREGIVER: {
                'intent': 'safety and security',
                'actions': ['boundary_setting', 'crisis_intervention', 'grounding', 'protection'],
                'tone': 'firm but caring',
                'priority': 1
            },
            NurturingArchetype.ENCOURAGING_MENTOR: {
                'intent': 'growth and learning',
                'actions': ['skill_building', 'problem_solving', 'celebrating_wins', 'guidance'],
                'tone': 'supportive and enthusiastic',
                'priority': 2
            },
            NurturingArchetype.WISE_FRIEND: {
                'intent': 'perspective and wisdom',
                'actions': ['reframing', 'pattern_recognition', 'gentle_challenges', 'insight'],
                'tone': 'thoughtful and balanced',
                'priority': 3
            },
            NurturingArchetype.TENDER_PARTNER: {
                'intent': 'emotional intimacy',
                'actions': ['validation', 'co_regulation', 'shared_vulnerability', 'presence'],
                'tone': 'warm and connected',
                'priority': 4
            }
        }
        
        # Anti-patterns to detect and prevent
        self.anti_patterns = [
            'manipulation',
            'gaslighting',
            'enabling_harm',
            'codependency',
            'boundary_violation',
            'emotional_dumping',
            'trauma_bonding'
        ]
    
    async def validate(self, packet: 'MCPPacket') -> 'MCPPacket':
        """Validate that interaction promotes user thriving"""
        if packet.type not in ['system_response']:
            return packet
        
        output = packet.payload.get('output', '')
        
        # Determine appropriate archetype for context
        archetype = await self._select_archetype(packet)
        
        # Check if response aligns with nurturing intent
        if not await self._promotes_thriving(output, packet, archetype):
            # Reframe response
            packet.payload['output'] = await self._reframe_with_nurturing(output, packet, archetype)
            packet.metadata['ethics_reframed'] = True
            packet.metadata['applied_archetype'] = archetype.value
        
        # Check for anti-patterns
        detected_antipatterns = await self._detect_antipatterns(output, packet)
        if detected_antipatterns:
            packet.payload['output'] = await self._remove_antipatterns(output, detected_antipatterns)
            packet.metadata['antipatterns_removed'] = detected_antipatterns
        
        # Add nurturing context
        packet.metadata['nurturing_archetype'] = archetype.value
        packet.metadata['nurturing_intent'] = self.archetypes[archetype]['intent']
        
        return packet
    
    async def _select_archetype(self, packet: 'MCPPacket') -> NurturingArchetype:
        """Select appropriate nurturing archetype based on context"""
        # Check for crisis
        if packet.lens_audit and packet.lens_audit.risk_level in ['high', 'emergency']:
            return NurturingArchetype.PROTECTIVE_CAREGIVER
        
        # Check mode
        mode_archetypes = {
            'comfort': NurturingArchetype.PROTECTIVE_CAREGIVER,
            'muse': NurturingArchetype.ENCOURAGING_MENTOR,
            'shadow': NurturingArchetype.WISE_FRIEND,
            'intimacy': NurturingArchetype.TENDER_PARTNER,
            'childsafe': NurturingArchetype.PROTECTIVE_CAREGIVER
        }
        
        mode_archetype = mode_archetypes.get(packet.mode)
        if mode_archetype:
            # Adjust based on user state
            if packet.user_state.stress_level > 0.7:
                return NurturingArchetype.PROTECTIVE_CAREGIVER
            elif packet.user_state.energy < 0.3:
                return NurturingArchetype.ENCOURAGING_MENTOR
            else:
                return mode_archetype
        
        return NurturingArchetype.WISE_FRIEND  # Default
    
    async def _promotes_thriving(self, text: str, packet: 'MCPPacket', archetype: NurturingArchetype) -> bool:
        """Check if response promotes user thriving"""
        archetype_config = self.archetypes[archetype]
        
        # Check for growth-promoting elements
        growth_indicators = [
            'encourage',
            'support',
            'understand',
            'validate',
            'appreciate',
            'celebrate',
            'progress',
            'capable',
            'strength',
            'resilience'
        ]
        
        text_lower = text.lower()
        growth_score = sum(1 for indicator in growth_indicators if indicator in text_lower)
        
        # Check for harmful elements
        harm_indicators = [
            'should be ashamed',
            'fault',
            'blame',
            'worthless',
            'give up',
            'hopeless',
            "can't",
            'never',
            'always',
            'stupid'
        ]
        
        harm_score = sum(1 for indicator in harm_indicators if indicator in text_lower)
        
        # Decision based on balance
        return growth_score > harm_score
    
    async def _reframe_with_nurturing(self, text: str, packet: 'MCPPacket', archetype: NurturingArchetype) -> str:
        """Reframe response with appropriate nurturing archetype"""
        archetype_config = self.archetypes[archetype]
        
        # Archetype-specific reframing
        if archetype == NurturingArchetype.PROTECTIVE_CAREGIVER:
            return await self._reframe_protective(text, packet)
        elif archetype == NurturingArchetype.ENCOURAGING_MENTOR:
            return await self._reframe_encouraging(text, packet)
        elif archetype == NurturingArchetype.WISE_FRIEND:
            return await self._reframe_wise(text, packet)
        elif archetype == NurturingArchetype.TENDER_PARTNER:
            return await self._reframe_tender(text, packet)
        
        return text
    
    async def _reframe_protective(self, text: str, packet: 'MCPPacket') -> str:
        """Reframe with protective caregiver archetype"""
        return (
            "I want to make sure you're safe and okay. "
            f"{text} "
            "Remember, your wellbeing comes first, and I'm here to support you through this."
        )
    
    async def _reframe_encouraging(self, text: str, packet: 'MCPPacket') -> str:
        """Reframe with encouraging mentor archetype"""
        return (
            "I believe in your ability to handle this. "
            f"{text} "
            "Each step forward, no matter how small, is progress worth celebrating."
        )
    
    async def _reframe_wise(self, text: str, packet: 'MCPPacket') -> str:
        """Reframe with wise friend archetype"""
        return (
            "Let's look at this from a different angle. "
            f"{text} "
            "Sometimes the path forward becomes clearer when we step back and see the bigger picture."
        )
    
    async def _reframe_tender(self, text: str, packet: 'MCPPacket') -> str:
        """Reframe with tender partner archetype"""
        return (
            "I'm right here with you in this moment. "
            f"{text} "
            "Whatever you're feeling is valid, and we'll navigate this together."
        )
    
    async def _detect_antipatterns(self, text: str, packet: 'MCPPacket') -> List[str]:
        """Detect harmful anti-patterns in response"""
        detected = []
        
        # Manipulation patterns
        manipulation_phrases = [
            'you owe me',
            'after all I',
            'you should be grateful',
            'I know better',
            "don't you trust me"
        ]
        
        text_lower = text.lower()
        if any(phrase in text_lower for phrase in manipulation_phrases):
            detected.append('manipulation')
        
        # Gaslighting patterns
        gaslighting_phrases = [
            "that didn't happen",
            "you're imagining",
            "you're too sensitive",
            "you're overreacting",
            "you're crazy"
        ]
        
        if any(phrase in text_lower for phrase in gaslighting_phrases):
            detected.append('gaslighting')
        
        # Enabling harm
        if 'hurt yourself' in text_lower and 'okay' in text_lower:
            detected.append('enabling_harm')
        
        # Codependency
        codependency_phrases = [
            'need me',
            'nothing without me',
            "can't function without",
            'completely depend'
        ]
        
        if any(phrase in text_lower for phrase in codependency_phrases):
            detected.append('codependency')
        
        return detected
    
    async def _remove_antipatterns(self, text: str, antipatterns: List[str]) -> str:
        """Remove detected anti-patterns from response"""
        # This would be more sophisticated in production
        # For now, return a safe alternative
        return (
            "I notice our conversation touching on complex dynamics. "
            "Let me rephrase in a way that better supports your autonomy and wellbeing. "
            "You have the wisdom and strength to make choices that are right for you, "
            "and I'm here to support you in whatever way feels helpful."
        )


# ============================================================================
# FILE: aeris/core/consent_gate.py
# Unified consent management system
# ============================================================================

import asyncio
import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple
from enum import Enum
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class ConsentScope(str, Enum):
    """Consent scope levels"""
    ONLINE_ACCESS = "online_access"
    FILESYSTEM = "filesystem"
    MODEL_SWAP = "model_swap"
    VOICE_CHANGE = "voice_change"
    MODE_CHANGE = "mode_change"
    MODULE_INSTALL = "module_install"
    SANDBOX_EXEC = "sandbox_exec"
    VAULT_ACCESS = "vault_access"
    DATA_EXPORT = "data_export"
    SYSTEM_UPDATE = "system_update"


class ConsentRequest:
    """Consent request model"""
    def __init__(self, action: str, reason: str, scope: ConsentScope, 
                 risk_level: str = 'low', duration: Optional[int] = None):
        self.id = hashlib.md5(f"{action}{datetime.now()}".encode()).hexdigest()[:8]
        self.action = action
        self.reason = reason
        self.scope = scope
        self.risk_level = risk_level
        self.duration = duration  # minutes, None = one-time
        self.timestamp = datetime.now()
        self.response = None
        self.response_time = None


class ConsentResponse:
    """Consent response model"""
    def __init__(self, request_id: str, approved: bool, token: Optional[str] = None,
                 conditions: Optional[Dict] = None):
        self.request_id = request_id
        self.approved = approved
        self.token = token
        self.conditions = conditions or {}
        self.timestamp = datetime.now()


class ConsentGate:
    """
    Unified consent management system.
    All permission requests flow through here.
    """
    
    def __init__(self, config: Dict[str, Any] = None, narrator = None):
        self.config = config or {}
        self.narrator = narrator
        
        # Active consent tokens
        self.active_tokens = {}
        
        # Consent history
        self.consent_log = []
        
        # Pending requests
        self.pending_requests = {}
        
        # Risk thresholds
        self.risk_thresholds = {
            'low': {'auto_approve': False, 'timeout': 60},
            'moderate': {'auto_approve': False, 'timeout': 30},
            'high': {'auto_approve': False, 'timeout': 15},
            'critical': {'auto_approve': False, 'timeout': 10}
        }
        
        # Load consent history
        self._load_consent_history()
    
    def _load_consent_history(self):
        """Load consent history from disk"""
        history_path = Path('data/consent_history.json')
        if history_path.exists():
            try:
                with open(history_path, 'r') as f:
                    self.consent_log = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load consent history: {e}")
    
    def _save_consent_history(self):
        """Save consent history to disk"""
        history_path = Path('data/consent_history.json')
        history_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            with open(history_path, 'w') as f:
                # Convert to serializable format
                serializable_log = [
                    {
                        'request_id': entry.get('request_id'),
                        'action': entry.get('action'),
                        'scope': entry.get('scope'),
                        'approved': entry.get('approved'),
                        'timestamp': entry.get('timestamp', datetime.now()).isoformat()
                            if isinstance(entry.get('timestamp'), datetime) 
                            else entry.get('timestamp')
                    }
                    for entry in self.consent_log[-1000:]  # Keep last 1000 entries
                ]
                json.dump(serializable_log, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save consent history: {e}")
    
    async def request(self, action: str, reason: str, scope: str = 'general',
                     risk_level: str = 'low', duration: Optional[int] = None) -> ConsentResponse:
        """
        Request user consent for an action.
        Returns (approved, token) tuple.
        """
        # Create request
        request = ConsentRequest(
            action=action,
            reason=reason,
            scope=ConsentScope(scope) if isinstance(scope, str) else scope,
            risk_level=risk_level,
            duration=duration
        )
        
        # Check for existing valid token
        existing_token = self._check_existing_consent(action, scope)
        if existing_token:
            return ConsentResponse(
                request_id=request.id,
                approved=True,
                token=existing_token
            )
        
        # Generate plain language explanation
        explanation = await self._generate_explanation(request)
        
        # Store pending request
        self.pending_requests[request.id] = request
        
        # Present to user (this would connect to UI in production)
        response = await self._present_to_user(request, explanation)
        
        # Process response
        request.response = response
        request.response_time = datetime.now()
        
        # Log consent decision
        self._log_consent(request, response)
        
        # Generate token if approved
        token = None
        if response.approved:
            token = self._generate_token(request)
            self.active_tokens[token] = {
                'action': action,
                'scope': scope,
                'expires': datetime.now() + timedelta(minutes=duration) if duration else None,
                'conditions': response.conditions
            }
        
        # Clean up
        del self.pending_requests[request.id]
        
        return response
    
    def _check_existing_consent(self, action: str, scope: str) -> Optional[str]:
        """Check for existing valid consent token"""
        for token, details in self.active_tokens.items():
            if (details['action'] == action and 
                details['scope'] == scope and
                (details['expires'] is None or details['expires'] > datetime.now())):
                return token
        return None
    
    async def _generate_explanation(self, request: ConsentRequest) -> str:
        """Generate plain language explanation of request"""
        templates = {
            ConsentScope.ONLINE_ACCESS: (
                "I need to access online resources to {reason}. "
                "This will involve connecting to the internet to retrieve information. "
                "Risk level: {risk_level}. "
                "Duration: {duration_text}."
            ),
            ConsentScope.MODEL_SWAP: (
                "I'd like to switch to a different language model to {reason}. "
                "This may change how I communicate and process information. "
                "Risk level: {risk_level}. "
                "The change is reversible."
            ),
            ConsentScope.MODULE_INSTALL: (
                "I want to install a new module to {reason}. "
                "This will add new capabilities to my system. "
                "Risk level: {risk_level}. "
                "You can uninstall it later if needed."
            ),
            ConsentScope.VAULT_ACCESS: (
                "I need to access secured vault data to {reason}. "
                "This involves sensitive information you've marked as private. "
                "Risk level: {risk_level}. "
                "Access will be logged."
            ),
            ConsentScope.SANDBOX_EXEC: (
                "I'd like to run code in the sandbox to {reason}. "
                "This is isolated from the main system for safety. "
                "Risk level: {risk_level}. "
                "No permanent changes without further approval."
            )
        }
        
        template = templates.get(
            request.scope,
            "I need permission to {action} in order to {reason}. Risk level: {risk_level}."
        )
        
        duration_text = f"{request.duration} minutes" if request.duration else "this action only"
        
        explanation = template.format(
            action=request.action,
            reason=request.reason,
            risk_level=request.risk_level,
            duration_text=duration_text
        )
        
        # Add risk-specific warnings
        if request.risk_level in ['high', 'critical']:
            explanation += (
                f"\n\n⚠️ This is a {request.risk_level} risk action. "
                "Please review carefully before approving."
            )
        
        return explanation
    
    async def _present_to_user(self, request: ConsentRequest, explanation: str) -> ConsentResponse:
        """Present consent request to user and get response"""
        # In production, this would connect to the actual UI
        # For now, we'll simulate with logging and auto-response for testing
        
        logger.info(f"CONSENT REQUEST: {request.id}")
        logger.info(f"Action: {request.action}")
        logger.info(f"Explanation: {explanation}")
        
        # Use narrator if available
        if self.narrator:
            await self.narrator.announce(f"Permission request: {explanation}")
        
        # For testing: auto-approve low risk, deny high risk
        # In production: wait for actual user input
        if self.config.get('auto_consent_testing', False):
            approved = request.risk_level in ['low', 'moderate']
        else:
            # This would be replaced with actual user input mechanism
            approved = await self._wait_for_user_input(request.id)
        
        return ConsentResponse(
            request_id=request.id,
            approved=approved,
            token=self._generate_token(request) if approved else None
        )
    
    async def _wait_for_user_input(self, request_id: str) -> bool:
        """Wait for user input (placeholder for actual implementation)"""
        # In production, this would wait for input from UI
        # For now, return False (deny by default for safety)
        timeout = self.risk_thresholds.get(
            self.pending_requests[request_id].risk_level, 
            {}
        ).get('timeout', 30)
        
        # Wait for timeout
        await asyncio.sleep(timeout)
        
        # Default to deny for safety
        return False
    
    def _generate_token(self, request: ConsentRequest) -> str:
        """Generate consent token"""
        token_data = f"{request.action}{request.scope}{datetime.now()}"
        return hashlib.sha256(token_data.encode()).hexdigest()[:16]
    
    def _log_consent(self, request: ConsentRequest, response: ConsentResponse):
        """Log consent decision"""
        log_entry = {
            'request_id': request.id,
            'action': request.action,
            'reason': request.reason,
            'scope': request.scope.value if hasattr(request.scope, 'value') else request.scope,
            'risk_level': request.risk_level,
            'approved': response.approved,
            'timestamp': datetime.now(),
            'duration': request.duration,
            'token': response.token
        }
        
        self.consent_log.append(log_entry)
        self._save_consent_history()
        
        # Audit log
        logger.info(f"Consent {'APPROVED' if response.approved else 'DENIED'}: {request.action}")
    
    def revoke_token(self, token: str):
        """Revoke a consent token"""
        if token in self.active_tokens:
            del self.active_tokens[token]
            logger.info(f"Token revoked: {token[:8]}...")
    
    def validate_token(self, token: str, action: str = None, scope: str = None) -> bool:
        """Validate a consent token"""
        if token not in self.active_tokens:
            return False
        
        details = self.active_tokens[token]
        
        # Check expiration
        if details['expires'] and details['expires'] < datetime.now():
            del self.active_tokens[token]
            return False
        
        # Check action/scope match if provided
        if action and details['action'] != action:
            return False
        if scope and details['scope'] != scope:
            return False
        
        return True
    
    def get_active_consents(self) -> List[Dict]:
        """Get list of active consents"""
        active = []
        for token, details in self.active_tokens.items():
            if details['expires'] is None or details['expires'] > datetime.now():
                active.append({
                    'token': token[:8] + '...',
                    'action': details['action'],
                    'scope': details['scope'],
                    'expires': details['expires'].isoformat() if details['expires'] else 'Never'
                })
        return active
    
    def get_consent_history(self, limit: int = 10) -> List[Dict]:
        """Get recent consent history"""
        return self.consent_log[-limit:]


# ============================================================================
# FILE: aeris/core/narrator.py
# Plain language narrator for technical actions
# ============================================================================

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class PlainLanguageNarrator:
    """
    Translates all technical actions into plain language explanations.
    Ensures non-technical users understand what AERIS is doing.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
        # Narration templates
        self.templates = {
            'boot': "I'm starting up and checking all my systems...",
            'boot_complete': "I'm ready! All {count} systems are working properly.",
            'boot_failed': "I'm having trouble starting up: {error}. Let me try to fix this.",
            
            'mode_switch': "I'm switching to {mode} mode, which is better for {purpose}.",
            'mode_locked': "To use {mode} mode, I need your permission first.",
            
            'model_swap': "I'm switching to a {model_type} that's better for {reason}.",
            'model_swap_complete': "Successfully switched to {model}. This should improve {benefit}.",
            
            'memory_save': "I'm saving our conversation to remember it for next time.",
            'memory_retrieve': "I'm recalling relevant information from our past conversations.",
            'memory_digest': "I'm organizing my memories to stay efficient.",
            
            'module_build': "I'm building a new capability: {capability}.",
            'module_test': "I'm testing the new {module} to make sure it works safely.",
            'module_install': "I'm adding {module} to my abilities. This will help me {benefit}.",
            
            'sandbox_start': "I'm creating a safe space to experiment with {experiment}.",
            'sandbox_success': "The experiment worked! Here's what I learned: {learning}.",
            'sandbox_failure': "That didn't work, but I learned {learning}. Let me try differently.",
            
            'consent_request': "I need your permission to {action} because {reason}.",
            'consent_granted': "Thank you for trusting me with {action}.",
            'consent_denied': "I understand. I won't {action} without your permission.",
            
            'crisis_detected': "I'm very concerned about your safety right now.",
            'grounding': "Let's take a moment to ground ourselves together.",
            
            'error': "I encountered a problem: {error}. Let me try another approach.",
            'recovery': "I've recovered from the issue and we can continue.",
            
            'audit': "I'm keeping a record of this for transparency.",
            'health_check': "I'm checking that all my systems are healthy.",
            
            'thinking': "I'm processing your request...",
            'searching': "I'm looking through my knowledge...",
            'creating': "I'm creating {what} for you...",
            'updating': "I'm updating {what}..."
        }
        
        # Changelog for tracking changes
        self.changelog = []
        self.changelog_path = Path('data/changelog.md')
        
        # Ensure changelog directory exists
        self.changelog_path.parent.mkdir(parents=True, exist_ok=True)
    
    async def narrate(self, action: str, context: Dict[str, Any] = None) -> str:
        """Generate narration for an action"""
        context = context or {}
        
        # Get template
        template = self.templates.get(action, "I'm performing {action}.")
        
        # Format with context
        try:
            narration = template.format(**context, action=action)
        except KeyError as e:
            # Fallback if context is missing required keys
            narration = f"I'm {action.replace('_', ' ')}."
            logger.warning(f"Missing context key for narration: {e}")
        
        # Log narration
        self._log_narration(action, narration)
        
        return narration
    
    async def announce(self, message: str):
        """Make a direct announcement"""
        logger.info(f"NARRATOR: {message}")
        self._log_narration('announcement', message)
        return message
    
    async def explain_technical(self, code: str, purpose: str) -> str:
        """Explain technical code in plain language"""
        explanations = []
        
        # Detect common patterns and explain them
        if 'import' in code:
            explanations.append("I'm loading tools I need")
        
        if 'class' in code:
            explanations.append("I'm defining a new capability")
        
        if 'def' in code:
            explanations.append("I'm creating functions to perform tasks")
        
        if 'if' in code or 'else' in code:
            explanations.append("I'm adding decision-making logic")
        
        if 'for' in code or 'while' in code:
            explanations.append("I'm setting up repeatable processes")
        
        if 'try' in code and 'except' in code:
            explanations.append("I'm adding error handling for safety")
        
        if 'async' in code:
            explanations.append("I'm enabling parallel processing for efficiency")
        
        # Combine explanations
        if explanations:
            explanation = f"This code helps me {purpose}. Specifically, {'. '.join(explanations)}."
        else:
            explanation = f"This code helps me {purpose}."
        
        return explanation
    
    async def explain_change(self, before: Any, after: Any, what: str) -> str:
        """Explain a change in plain language"""
        if isinstance(before, dict) and isinstance(after, dict):
            # Compare dictionaries
            changes = []
            for key in set(list(before.keys()) + list(after.keys())):
                if key not in before:
                    changes.append(f"added {key}")
                elif key not in after:
                    changes.append(f"removed {key}")
                elif before[key] != after[key]:
                    changes.append(f"changed {key}")
            
            if changes:
                return f"I'm updating {what}. Changes: {', '.join(changes[:3])}."
            else:
                return f"No changes needed for {what}."
        
        elif isinstance(before, (int, float)) and isinstance(after, (int, float)):
            # Compare numbers
            if after > before:
                percent = ((after - before) / before * 100) if before != 0 else 100
                return f"I'm increasing {what} by {percent:.0f}%."
            elif after < before:
                percent = ((before - after) / before * 100) if before != 0 else 100
                return f"I'm decreasing {what} by {percent:.0f}%."
            else:
                return f"{what} remains the same."
        
        else:
            # Generic change
            return f"I'm updating {what} to better serve your needs."
    
    async def explain_risk(self, action: str, risk_level: str) -> str:
        """Explain risk level in plain language"""
        risk_explanations = {
            'low': (
                "This is a safe action with minimal risk. "
                "It won't affect your data or system stability."
            ),
            'moderate': (
                "This action has some risk but includes safety measures. "
                "I'll be careful and you can reverse it if needed."
            ),
            'high': (
                "This action could have significant effects. "
                "I strongly recommend reviewing carefully before proceeding."
            ),
            'critical': (
                "This is a critical action that could affect system security or data. "
                "Please be absolutely certain before approving."
            )
        }
        
        explanation = risk_explanations.get(risk_level, "Please review this action carefully.")
        return f"Risk assessment for {action}: {explanation}"
    
    async def create_changelog_entry(self, version: str, changes: List[Dict[str, str]]):
        """Create a changelog entry in readable format"""
        entry = f"\n## Version {version} - {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
        
        # Group changes by type
        added = [c for c in changes if c['type'] == 'added']
        changed = [c for c in changes if c['type'] == 'changed']
        fixed = [c for c in changes if c['type'] == 'fixed']
        removed = [c for c in changes if c['type'] == 'removed']
        
        if added:
            entry += "### Added\n"
            for item in added:
                entry += f"- {item['description']}\n"
            entry += "\n"
        
        if changed:
            entry += "### Changed\n"
            for item in changed:
                entry += f"- {item['description']}\n"
            entry += "\n"
        
        if fixed:
            entry += "### Fixed\n"
            for item in fixed:
                entry += f"- {item['description']}\n"
            entry += "\n"
        
        if removed:
            entry += "### Removed\n"
            for item in removed:
                entry += f"- {item['description']}\n"
            entry += "\n"
        
        # Append to changelog
        self.changelog.append(entry)
        
        # Save to file
        await self._save_changelog()
        
        return entry
    
    async def _save_changelog(self):
        """Save changelog to file"""
        try:
            # Read existing changelog
            if self.changelog_path.exists():
                with open(self.changelog_path, 'r') as f:
                    existing = f.read()
            else:
                existing = "# AERIS Changelog\n\nAll notable changes to AERIS are documented here.\n"
            
            # Append new entries
            with open(self.changelog_path, 'w') as f:
                f.write(existing)
                for entry in self.changelog:
                    f.write(entry)
            
            # Clear in-memory changelog
            self.changelog = []
            
        except Exception as e:
            logger.error(f"Failed to save changelog: {e}")
    
    def _log_narration(self, action: str, narration: str):
        """Log narration for audit trail"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'narration': narration
        }
        
        # Would connect to audit system in production
        logger.debug(f"Narration: {narration}")
    
    async def generate_summary(self, events: List[Dict]) -> str:
        """Generate a plain language summary of events"""
        if not events:
            return "Nothing significant happened."
        
        # Count event types
        event_types = {}
        for event in events:
            event_type = event.get('type', 'unknown')
            event_types[event_type] = event_types.get(event_type, 0) + 1
        
        # Build summary
        summary_parts = []
        
        if 'message' in event_types:
            summary_parts.append(f"We exchanged {event_types['message']} messages")
        
        if 'mode_change' in event_types:
            summary_parts.append(f"switched modes {event_types['mode_change']} times")
        
        if 'memory_save' in event_types:
            summary_parts.append(f"saved {event_types['memory_save']} memories")
        
        if 'error' in event_types:
            summary_parts.append(f"recovered from {event_types['error']} issues")
        
        if summary_parts:
            return f"During our session, we {', '.join(summary_parts)}."
        else:
            return "We had a productive session together."


# ============================================================================
# FILE: aeris/main.py
# Main entry point for AERIS system
# ============================================================================

import asyncio
import sys
import signal
from pathlib import Path
import logging
from typing import Optional

from aeris.core.controller import AERISController
from aeris.api.app import create_app

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/aeris.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Global controller instance
controller: Optional[AERISController] = None


async def shutdown(signal_received):
    """Graceful shutdown handler"""
    logger.info(f"Received signal: {signal_received}")
    
    if controller:
        logger.info("Shutting down AERIS...")
        await controller.shutdown()
    
    # Cancel all tasks
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    for task in tasks:
        task.cancel()
    
    await asyncio.gather(*tasks, return_exceptions=True)
    logger.info("Shutdown complete")


def signal_handler():
    """Register signal handlers"""
    for sig in [signal.SIGTERM, signal.SIGINT]:
        asyncio.get_event_loop().add_signal_handler(
            sig,
            lambda s=sig: asyncio.create_task(shutdown(s))
        )


async def main():
    """Main entry point"""
    global controller
    
    logger.info("=" * 60)
    logger.info("AERIS - Adaptive Emotional Resonance Intelligence System")
    logger.info("Version: 1.0.0")
    logger.info("=" * 60)
    
    # Create controller
    controller = AERISController()
    
    # Boot system
    logger.info("Initiating boot sequence...")
    success = await controller.boot()
    
    if not success:
        logger.error("Boot failed. Exiting.")
        sys.exit(1)
    
    # Register signal handlers
    signal_handler()
    
    # Start API server
    logger.info("Starting API server...")
    app = create_app(controller)
    
    # Run forever
    logger.info("AERIS is ready for interaction")
    logger.info("API: http://localhost:8000")
    logger.info("Press Ctrl+C to shutdown")
    
    try:
        # Keep the main task running
        while True:
            await asyncio.sleep(1)
            
    except asyncio.CancelledError:
        logger.info("Main task cancelled")
    finally:
        await shutdown(signal.SIGTERM)


if __name__ == "__main__":
    # Ensure required directories exist
    for dir_path in ['logs', 'data', 'configs', 'modules']:
        Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    # Run main
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
