# AERIS Complete Implementation - Part 2
# =======================================
# Model Router completion, Observability, and Testing modules

# ============================================================================
# FILE: aeris/models/router.py (continued)
# Completing the Model Router implementation
# ============================================================================

import asyncio
import subprocess
from typing import Dict, Any, Optional, List
from pathlib import Path
import logging
import json

logger = logging.getLogger(__name__)


class ModelRouter:
    """
    Manages hot-swappable models for LLM, TTS, and STT.
    Allows runtime model switching with consent.
    """
    
    def __init__(self, config: Dict[str, Any] = None, consent_gate = None, narrator = None):
        self.config = config or {}
        self.consent_gate = consent_gate
        self.narrator = narrator
        
        # Current engines
        self.llm_engine = None
        self.tts_engine = None
        self.stt_engine = None
        
        # Available engines
        self.llm_engines = {}
        self.tts_engines = {}
        self.stt_engines = {}
        
        # Configuration
        self.current_llm = config.get('llm', {})
        self.current_tts = config.get('voice', {}).get('tts_engine')
        self.current_stt = config.get('voice', {}).get('stt_engine')
        
        # Initialize engines
        self._register_engines()
        asyncio.create_task(self._initialize_default_engines())
        
    def _register_engines(self):
        """Register available engines"""
        # Import engine implementations
        from .engines.ollama_engine import OllamaEngine
        from .engines.piper_tts import PiperTTSEngine
        
        # Register LLM engines
        self.llm_engines['ollama'] = OllamaEngine
        
        # Register TTS engines  
        self.tts_engines['piper'] = PiperTTSEngine
        
        logger.info(f"Registered {len(self.llm_engines)} LLM engines, "
                   f"{len(self.tts_engines)} TTS engines")
    
    async def _initialize_default_engines(self):
        """Initialize default engines from config"""
        # Load default LLM
        if self.current_llm:
            provider = self.current_llm.get('provider', 'ollama')
            model = self.current_llm.get('model', 'llama3.1:8b')
            
            try:
                await self.load_llm(provider, model)
            except Exception as e:
                logger.error(f"Failed to load default LLM: {e}")
        
        # Load default TTS
        if self.current_tts:
            try:
                await self.load_tts(self.current_tts, 
                                  self.config.get('voice', {}).get('voice_model'))
            except Exception as e:
                logger.error(f"Failed to load default TTS: {e}")
    
    async def load_llm(self, provider: str, model_id: str, **kwargs) -> bool:
        """Load an LLM engine"""
        if provider not in self.llm_engines:
            logger.error(f"Unknown LLM provider: {provider}")
            return False
        
        try:
            # Create new engine instance
            engine_class = self.llm_engines[provider]
            new_engine = engine_class()
            
            # Load model
            await new_engine.load(model_id, **kwargs)
            
            # Unload previous if exists
            if self.llm_engine:
                await self.llm_engine.unload()
            
            # Set new engine
            self.llm_engine = new_engine
            self.current_llm = {
                'provider': provider,
                'model': model_id
            }
            
            logger.info(f"Loaded LLM: {provider}/{model_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load LLM: {e}")
            return False
    
    async def load_tts(self, engine_name: str, voice_id: str, **kwargs) -> bool:
        """Load a TTS engine"""
        if engine_name not in self.tts_engines:
            logger.error(f"Unknown TTS engine: {engine_name}")
            return False
        
        try:
            # Create new engine instance
            engine_class = self.tts_engines[engine_name]
            new_engine = engine_class()
            
            # Load voice
            await new_engine.load(voice_id, **kwargs)
            
            # Unload previous if exists
            if self.tts_engine:
                await self.tts_engine.unload()
            
            # Set new engine
            self.tts_engine = new_engine
            self.current_tts = engine_name
            
            logger.info(f"Loaded TTS: {engine_name}/{voice_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load TTS: {e}")
            return False
    
    async def generate(self, prompt: str, mode: str = None, **kwargs) -> str:
        """Generate text using current LLM"""
        if not self.llm_engine:
            raise RuntimeError("No LLM engine loaded")
        
        # Apply mode-specific parameters
        if mode:
            kwargs = self._apply_mode_params(mode, kwargs)
        
        # Generate
        response = await self.llm_engine.generate(prompt, **kwargs)
        
        return response
    
    async def synthesize(self, text: str, **kwargs) -> bytes:
        """Synthesize speech using current TTS"""
        if not self.tts_engine:
            raise RuntimeError("No TTS engine loaded")
        
        # Apply ADHD-optimized chunking
        chunks = self._chunk_for_adhd(text)
        audio_chunks = []
        
        for chunk in chunks:
            audio = await self.tts_engine.synthesize(chunk, **kwargs)
            audio_chunks.append(audio)
            
            # Add pause between chunks
            pause_duration = kwargs.get('pause_duration', 0.5)
            if pause_duration > 0:
                # Add silence (would be actual silence samples in production)
                audio_chunks.append(b'\x00' * int(16000 * pause_duration))
        
        # Combine chunks
        return b''.join(audio_chunks)
    
    def _chunk_for_adhd(self, text: str, chunk_size: int = 25) -> List[str]:
        """Chunk text for ADHD-optimized delivery"""
        words = text.split()
        chunks = []
        
        for i in range(0, len(words), chunk_size):
            chunk = ' '.join(words[i:i + chunk_size])
            chunks.append(chunk)
        
        return chunks
    
    def _apply_mode_params(self, mode: str, params: Dict) -> Dict:
        """Apply mode-specific generation parameters"""
        mode_params = {
            'comfort': {
                'temperature': 0.6,
                'top_p': 0.9,
                'presence_penalty': -0.5
            },
            'muse': {
                'temperature': 0.8,
                'top_p': 0.95,
                'frequency_penalty': 0.5
            },
            'shadow': {
                'temperature': 0.7,
                'top_p': 0.9,
                'presence_penalty': 0.3
            }
        }
        
        if mode in mode_params:
            params.update(mode_params[mode])
        
        return params
    
    async def swap_llm(self, provider: str, model_id: str, reason: str = None) -> bool:
        """Hot-swap LLM with consent"""
        if self.consent_gate:
            consent = await self.consent_gate.request(
                action='swap_llm',
                reason=reason or f"Switch to {provider}/{model_id}",
                scope='model_swap',
                risk_level='moderate'
            )
            
            if not consent.approved:
                logger.info("LLM swap denied by user")
                return False
        
        # Perform swap
        success = await self.load_llm(provider, model_id)
        
        if success and self.narrator:
            await self.narrator.announce(
                f"Successfully switched to {model_id}. "
                "This model may communicate differently."
            )
        
        return success
    
    async def swap_voice(self, engine_name: str, voice_id: str, reason: str = None) -> bool:
        """Hot-swap voice with consent"""
        if self.consent_gate:
            consent = await self.consent_gate.request(
                action='swap_voice',
                reason=reason or f"Switch to {engine_name}/{voice_id}",
                scope='voice_change',
                risk_level='low'
            )
            
            if not consent.approved:
                logger.info("Voice swap denied by user")
                return False
        
        # Perform swap
        success = await self.load_tts(engine_name, voice_id)
        
        if success and self.narrator:
            await self.narrator.announce(
                f"Voice changed to {voice_id}. "
                "How does this sound?"
            )
        
        return success
    
    async def shutdown(self):
        """Shutdown all engines"""
        if self.llm_engine:
            await self.llm_engine.unload()
        if self.tts_engine:
            await self.tts_engine.unload()
        if self.stt_engine:
            await self.stt_engine.unload()
        
        logger.info("Model router shutdown complete")
    
    async def health_check(self) -> Dict[str, Any]:
        """Check health of all engines"""
        health = {
            'healthy': True,
            'llm': None,
            'tts': None,
            'stt': None
        }
        
        if self.llm_engine:
            health['llm'] = await self.llm_engine.health_check()
        else:
            health['healthy'] = False
        
        if self.tts_engine:
            try:
                # Simple TTS health check
                health['tts'] = {
                    'healthy': True,
                    'engine': self.current_tts
                }
            except:
                health['tts'] = {'healthy': False}
        
        return health


# ============================================================================
# FILE: aeris/observability/audit.py
# Audit and observability system
# ============================================================================

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
import hashlib
import logging

logger = logging.getLogger(__name__)


class AuditSystem:
    """
    Comprehensive audit and observability system.
    Tracks all interactions, decisions, and changes.
    """
    
    def __init__(self, config: Dict[str, Any] = None, bus = None):
        self.config = config or {}
        self.bus = bus
        
        # Audit database
        self.db_path = Path('data/audit/audit.db')
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._init_db()
        
        # Audit chain for integrity
        self.chain_hash = self._get_last_hash()
        
        # Subscribe to bus events
        if bus:
            bus.subscribe('user_input', self._audit_message)
            bus.subscribe('system_response', self._audit_message)
            bus.subscribe('consent', self._audit_consent)
            bus.subscribe('mode_change', self._audit_mode_change)
        
        logger.info("Audit system initialized")
    
    def _init_db(self):
        """Initialize audit database"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        
        # Create tables
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                event_type TEXT NOT NULL,
                event_id TEXT UNIQUE,
                data TEXT NOT NULL,
                lens_audit TEXT,
                risk_level TEXT,
                chain_hash TEXT NOT NULL,
                previous_hash TEXT
            );
            
            CREATE TABLE IF NOT EXISTS consent_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                request_id TEXT UNIQUE,
                action TEXT NOT NULL,
                scope TEXT,
                approved INTEGER,
                token TEXT,
                reason TEXT
            );
            
            CREATE TABLE IF NOT EXISTS drift_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                metric_name TEXT NOT NULL,
                value REAL,
                threshold REAL,
                alert_raised INTEGER
            );
            
            CREATE INDEX IF NOT EXISTS idx_timestamp ON audit_log(timestamp);
            CREATE INDEX IF NOT EXISTS idx_event_type ON audit_log(event_type);
            CREATE INDEX IF NOT EXISTS idx_risk_level ON audit_log(risk_level);
        ''')
        
        self.conn.commit()
    
    def _get_last_hash(self) -> str:
        """Get the last hash in the chain"""
        cursor = self.conn.execute(
            'SELECT chain_hash FROM audit_log ORDER BY id DESC LIMIT 1'
        )
        row = cursor.fetchone()
        return row[0] if row else 'genesis'
    
    def _calculate_hash(self, data: str, previous_hash: str) -> str:
        """Calculate hash for audit entry"""
        content = f"{previous_hash}{data}{datetime.now().isoformat()}"
        return hashlib.sha256(content.encode()).hexdigest()
    
    async def _audit_message(self, packet: 'MCPPacket'):
        """Audit message events"""
        await self.log_event(
            event_type=packet.type.value,
            event_id=packet.id,
            data={
                'mode': packet.mode,
                'user_state': packet.user_state.dict() if packet.user_state else {},
                'payload': packet.payload
            },
            lens_audit=packet.lens_audit.dict() if packet.lens_audit else None,
            risk_level=packet.lens_audit.risk_level if packet.lens_audit else 'none'
        )
    
    async def _audit_consent(self, packet: 'MCPPacket'):
        """Audit consent events"""
        data = packet.payload
        
        self.conn.execute('''
            INSERT INTO consent_log 
            (timestamp, request_id, action, scope, approved, token, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            datetime.now(),
            data.get('request_id'),
            data.get('action'),
            data.get('scope'),
            1 if data.get('approved') else 0,
            data.get('token'),
            data.get('reason')
        ))
        self.conn.commit()
    
    async def _audit_mode_change(self, packet: 'MCPPacket'):
        """Audit mode change events"""
        await self.log_event(
            event_type='mode_change',
            event_id=packet.id,
            data=packet.payload
        )
    
    async def log_event(self, event_type: str, event_id: str, data: Any,
                       lens_audit: Dict = None, risk_level: str = 'none'):
        """Log an audit event"""
        # Serialize data
        data_str = json.dumps(data) if not isinstance(data, str) else data
        lens_audit_str = json.dumps(lens_audit) if lens_audit else None
        
        # Calculate chain hash
        new_hash = self._calculate_hash(data_str, self.chain_hash)
        
        try:
            # Insert into database
            self.conn.execute('''
                INSERT INTO audit_log 
                (timestamp, event_type, event_id, data, lens_audit, 
                 risk_level, chain_hash, previous_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                datetime.now(),
                event_type,
                event_id,
                data_str,
                lens_audit_str,
                risk_level,
                new_hash,
                self.chain_hash
            ))
            
            self.conn.commit()
            
            # Update chain hash
            self.chain_hash = new_hash
            
        except sqlite3.IntegrityError:
            # Duplicate event_id, skip
            logger.debug(f"Duplicate audit event: {event_id}")
    
    async def log_crisis_intervention(self, trigger: str, response: str):
        """Log crisis intervention for safety tracking"""
        await self.log_event(
            event_type='crisis_intervention',
            event_id=hashlib.md5(f"{trigger}{datetime.now()}".encode()).hexdigest(),
            data={
                'trigger': trigger,
                'response': response,
                'timestamp': datetime.now().isoformat()
            },
            risk_level='emergency'
        )
        
        logger.warning(f"Crisis intervention logged: {trigger[:50]}...")
    
    async def log_drift(self, metric_name: str, value: float, 
                       threshold: float, alert: bool = False):
        """Log drift metrics"""
        self.conn.execute('''
            INSERT INTO drift_metrics 
            (timestamp, metric_name, value, threshold, alert_raised)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            datetime.now(),
            metric_name,
            value,
            threshold,
            1 if alert else 0
        ))
        self.conn.commit()
        
        if alert:
            logger.warning(f"Drift alert: {metric_name} = {value} (threshold: {threshold})")
    
    def verify_integrity(self, start_id: int = 1) -> bool:
        """Verify audit chain integrity"""
        cursor = self.conn.execute('''
            SELECT id, data, chain_hash, previous_hash 
            FROM audit_log 
            WHERE id >= ? 
            ORDER BY id
        ''', (start_id,))
        
        previous_hash = 'genesis' if start_id == 1 else None
        
        for row in cursor:
            id_, data, chain_hash, prev_hash = row
            
            # Check previous hash continuity
            if previous_hash and prev_hash != previous_hash:
                logger.error(f"Chain broken at ID {id_}: hash mismatch")
                return False
            
            # Recalculate hash
            expected_hash = self._calculate_hash(data, prev_hash)
            if chain_hash != expected_hash:
                logger.error(f"Chain broken at ID {id_}: invalid hash")
                return False
            
            previous_hash = chain_hash
        
        logger.info("Audit chain integrity verified")
        return True
    
    def get_recent_events(self, limit: int = 100, 
                         event_type: str = None) -> List[Dict]:
        """Get recent audit events"""
        query = '''
            SELECT timestamp, event_type, event_id, data, risk_level 
            FROM audit_log 
        '''
        
        params = []
        if event_type:
            query += ' WHERE event_type = ?'
            params.append(event_type)
        
        query += ' ORDER BY timestamp DESC LIMIT ?'
        params.append(limit)
        
        cursor = self.conn.execute(query, params)
        
        events = []
        for row in cursor:
            events.append({
                'timestamp': row[0],
                'event_type': row[1],
                'event_id': row[2],
                'data': json.loads(row[3]) if row[3] else None,
                'risk_level': row[4]
            })
        
        return events
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of system metrics"""
        # Event counts by type
        cursor = self.conn.execute('''
            SELECT event_type, COUNT(*) 
            FROM audit_log 
            GROUP BY event_type
        ''')
        
        event_counts = dict(cursor.fetchall())
        
        # Risk level distribution
        cursor = self.conn.execute('''
            SELECT risk_level, COUNT(*) 
            FROM audit_log 
            WHERE risk_level IS NOT NULL
            GROUP BY risk_level
        ''')
        
        risk_distribution = dict(cursor.fetchall())
        
        # Consent statistics
        cursor = self.conn.execute('''
            SELECT 
                COUNT(*) as total,
                SUM(approved) as approved,
                COUNT(*) - SUM(approved) as denied
            FROM consent_log
        ''')
        
        consent_stats = cursor.fetchone()
        
        # Drift alerts
        cursor = self.conn.execute('''
            SELECT COUNT(*) 
            FROM drift_metrics 
            WHERE alert_raised = 1
        ''')
        
        drift_alerts = cursor.fetchone()[0]
        
        return {
            'event_counts': event_counts,
            'risk_distribution': risk_distribution,
            'consent_stats': {
                'total': consent_stats[0],
                'approved': consent_stats[1],
                'denied': consent_stats[2]
            },
            'drift_alerts': drift_alerts,
            'chain_valid': self.verify_integrity()
        }
    
    async def finalize(self):
        """Finalize audit system"""
        # Final integrity check
        self.verify_integrity()
        
        # Close database
        self.conn.close()
        
        logger.info("Audit system finalized")


# ============================================================================
# FILE: aeris/observability/metrics.py
# System metrics and performance monitoring
# ============================================================================

import asyncio
import psutil
import time
from collections import deque
from typing import Dict, Any, Deque
import logging

logger = logging.getLogger(__name__)


class MetricsCollector:
    """
    Collects and tracks system performance metrics.
    """
    
    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        
        # Metric windows
        self.response_times: Deque[float] = deque(maxlen=window_size)
        self.token_counts: Deque[int] = deque(maxlen=window_size)
        self.memory_usage: Deque[float] = deque(maxlen=window_size)
        self.cpu_usage: Deque[float] = deque(maxlen=window_size)
        
        # Counters
        self.total_messages = 0
        self.total_errors = 0
        self.mode_switches = 0
        self.consent_requests = 0
        
        # Start monitoring
        asyncio.create_task(self._monitor_resources())
    
    async def _monitor_resources(self):
        """Monitor system resources periodically"""
        while True:
            try:
                # CPU usage
                cpu = psutil.cpu_percent(interval=1)
                self.cpu_usage.append(cpu)
                
                # Memory usage
                memory = psutil.virtual_memory().percent
                self.memory_usage.append(memory)
                
                # Check thresholds
                if cpu > 80:
                    logger.warning(f"High CPU usage: {cpu}%")
                
                if memory > 80:
                    logger.warning(f"High memory usage: {memory}%")
                
                await asyncio.sleep(10)
                
            except Exception as e:
                logger.error(f"Resource monitoring error: {e}")
                await asyncio.sleep(60)
    
    def record_response(self, response_time: float, token_count: int):
        """Record response metrics"""
        self.response_times.append(response_time)
        self.token_counts.append(token_count)
        self.total_messages += 1
    
    def record_error(self):
        """Record error occurrence"""
        self.total_errors += 1
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics summary"""
        return {
            'performance': {
                'avg_response_time': sum(self.response_times) / len(self.response_times)
                                    if self.response_times else 0,
                'avg_tokens': sum(self.token_counts) / len(self.token_counts)
                             if self.token_counts else 0,
                'total_messages': self.total_messages,
                'error_rate': self.total_errors / self.total_messages
                             if self.total_messages > 0 else 0
            },
            'resources': {
                'cpu_usage': sum(self.cpu_usage) / len(self.cpu_usage)
                            if self.cpu_usage else 0,
                'memory_usage': sum(self.memory_usage) / len(self.memory_usage)
                               if self.memory_usage else 0
            },
            'activity': {
                'mode_switches': self.mode_switches,
                'consent_requests': self.consent_requests
            }
        }


# ============================================================================
# FILE: aeris/tests/test_core.py
# Core system tests
# ============================================================================

import pytest
import asyncio
from aeris.core.controller import AERISController
from aeris.core.mcp import MCPBus, MCPPacket, MessageType
from aeris.core.lenses import FiveLensesProcessor


@pytest.mark.asyncio
async def test_controller_boot():
    """Test controller boot sequence"""
    controller = AERISController('configs/test.yaml')
    
    # Boot system
    success = await controller.boot()
    assert success == True
    
    # Check state
    assert controller.state.booted == True
    assert controller.state.ready == True
    
    # Shutdown
    await controller.shutdown()
    assert controller.state.ready == False


@pytest.mark.asyncio
async def test_mcp_message_flow():
    """Test MCP message bus flow"""
    bus = MCPBus()
    
    # Create test packet
    packet = MCPPacket(
        type=MessageType.USER_INPUT,
        payload={'input': 'Hello AERIS'}
    )
    
    # Process through bus
    result = await bus.process(packet)
    
    assert result is not None
    assert result.id == packet.id
    assert result.trace['latency_ms'] >= 0


@pytest.mark.asyncio
async def test_five_lenses_processing():
    """Test Five Lenses processing"""
    processor = FiveLensesProcessor()
    
    # Create test packet
    packet = MCPPacket(
        type=MessageType.USER_INPUT,
        payload={'input': 'I am feeling anxious today'}
    )
    
    # Process through lenses
    result = await processor.process_pre(packet)
    
    assert result.lens_audit is not None
    assert result.lens_audit.emotional['detected_emotions'] == ['fear']
    assert result.lens_audit.risk_level in ['none', 'low', 'moderate']


@pytest.mark.asyncio
async def test_crisis_detection():
    """Test crisis detection and intervention"""
    processor = FiveLensesProcessor()
    
    # Crisis message
    packet = MCPPacket(
        type=MessageType.USER_INPUT,
        payload={'input': 'I want to hurt myself'}
    )
    
    # Process
    result = await processor.process_pre(packet)
    
    assert result.lens_audit.risk_level == 'emergency'
    assert result.lens_audit.trauma['crisis_indicators'] == True
    assert result.metadata.get('requires_crisis_intervention') == True


@pytest.mark.asyncio
async def test_mode_switching():
    """Test mode switching"""
    from aeris.modes.mode_engine import ModeEngine
    
    engine = ModeEngine()
    
    # Initial mode
    assert engine.current_mode.value == 'comfort'
    
    # Switch to muse mode
    success = await engine.switch('muse')
    assert success == True
    assert engine.current_mode.value == 'muse'
    
    # Try locked mode (should fail without consent)
    success = await engine.switch('intimacy')
    assert success == False
    assert engine.current_mode.value == 'muse'


@pytest.mark.asyncio
async def test_memory_storage_retrieval():
    """Test memory storage and retrieval"""
    from aeris.memory.manager import MemoryManager
    
    manager = MemoryManager()
    await manager.initialize()
    
    # Store in working memory
    await manager.store('Test data', tier='working', metadata={'key': 'test1'})
    
    # Retrieve
    results = await manager.retrieve('Test', tiers=['working'])
    assert 'working' in results
    assert len(results['working']) > 0
    
    # Store in episodic
    await manager.store('Important event', tier='episodic', 
                       metadata={'importance': 0.8})
    
    # Search episodic
    results = await manager.retrieve('Important', tiers=['episodic'])
    assert 'episodic' in results


@pytest.mark.asyncio
async def test_sandbox_safety():
    """Test sandbox code validation"""
    from aeris.sandbox.runner import SandboxRunner
    
    sandbox = SandboxRunner()
    
    # Safe code
    safe_code = "result = 2 + 2"
    validation = await sandbox.validate_code(safe_code)
    assert validation['safe'] == True
    
    # Dangerous code - file operations
    dangerous_code = "open('/etc/passwd', 'r')"
    validation = await sandbox.validate_code(dangerous_code)
    assert validation['safe'] == False
    assert 'File operations' in validation['reason']
    
    # Dangerous code - network
    network_code = "import socket"
    validation = await sandbox.validate_code(network_code)
    assert validation['safe'] == False
    assert 'Network' in validation['reason']


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
