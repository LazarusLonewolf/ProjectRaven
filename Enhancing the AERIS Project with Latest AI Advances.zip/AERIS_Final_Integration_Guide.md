# AERIS Final Integration Guide
# ==============================
# Combining all blueprints and implementations into deployment-ready system

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                     USER INTERFACE                       │
│          Text Shell + Voice + Future GUI/Mobile          │
└────────────────────────┬────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│                    FastAPI (Port 8000)                   │
│     /health  /core/message  /media/*  /system/swap       │
└────────────────────────┬────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│                   CORE CONTROLLER                        │
│        Boot → MCP Bus → State Management → Health        │
└────────────────────────┬────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│              MCP MESSAGE BUS (Event-Driven)              │
│         All Components Communicate Through Here          │
└──┬──────────────┬─────────────┬──────────────┬─────────┘
   │              │             │              │
┌──▼──────┐ ┌────▼────┐ ┌─────▼─────┐ ┌─────▼──────┐
│  FIVE   │ │ ETHICS  │ │  CONSENT  │ │  NARRATOR  │
│ LENSES  │ │  GUARD  │ │   GATE    │ │   PLAIN    │
│         │ │NURTURING│ │  UNIFIED  │ │  LANGUAGE  │
└─────────┘ └─────────┘ └───────────┘ └────────────┘
   │              │             │              │
┌──▼──────────────▼─────────────▼──────────────▼─────────┐
│                    CORE SERVICES                        │
├──────────────────────────────────────────────────────────┤
│ • Memory Manager (4-tier + vector DB)                   │
│ • Model Router (Ollama/Qwen 2.5 + hot-swap)            │
│ • Mode Engine (5 modes with templates)                  │
│ • Sandbox Runner (isolated + Raphael Loop)              │
│ • Module Manager (auto-rollback on failure)             │
│ • Multimodal Engines (image/audio/video stubs)          │
│ • Resource Monitor (spoon estimator)                    │
│ • Audit System (chain integrity + observability)        │
└──────────────────────────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│                   DATA STORAGE                           │
│   SQLite + ChromaDB + Encrypted Vault + File System     │
└──────────────────────────────────────────────────────────┘
```

## Deployment Strategy (Production-Ready)

### Phase 0: Environment Setup (Day 1)

```bash
# 1. System Requirements Check
- Windows 11 with WSL2 enabled
- Docker Desktop with NVIDIA support
- GTX 1660 SUPER drivers installed
- 16GB RAM available
- 100GB+ storage for models

# 2. One-Click Setup (PowerShell as Admin)
./scripts/setup.ps1

# This will:
- Create directory structure
- Start Docker containers
- Pull Qwen 2.5 7B model
- Initialize databases
- Run health checks
```

### Phase 1: Core Implementation (Weeks 1-8)

#### Sprint 1: Foundation (Weeks 1-2)
```python
# Files to implement first:
aeris/core/controller.py      # Boot sequence
aeris/core/mcp.py             # Message bus
aeris/api/app.py              # FastAPI endpoints
aeris/configs/core.yaml       # Configuration

# Test: System boots in <5s
```

#### Sprint 2: Five Lenses + Ethics (Weeks 3-4)
```python
# Critical safety layer:
aeris/core/lenses/
  ├── emotional.py     # Emotion detection
  ├── trauma.py        # Trigger awareness
  ├── spiritual.py     # Non-dogmatic meaning
  ├── science.py       # Fact checking
  └── logic.py         # Coherence validation

aeris/core/ethics_guard.py    # Nurturing framework
aeris/core/lens_engine.py     # Aggregator

# Test: Harmful content blocked/reframed
```

#### Sprint 3: Consent + Narration (Weeks 5-6)
```python
# Human-in-the-loop safety:
aeris/core/consent_gate.py    # Permission system
aeris/core/narrator.py        # Plain language explanations

# Test: All actions require/explain consent
```

#### Sprint 4: Memory + Modes (Weeks 7-8)
```python
# Persistence and personality:
aeris/memory/manager.py       # 4-tier system
aeris/modes/mode_engine.py    # 5 interaction modes
aeris/models/router.py        # LLM/TTS management

# Test: Remembers context, switches modes safely
```

### Phase 2: Self-Evolution (Weeks 9-12)

#### Sprint 5: Sandbox + Validation
```python
# Safe experimentation:
aeris/sandbox/runner.py       # Isolated execution
aeris/sandbox/raphael.py      # Retry loop
aeris/core/module_manager.py  # Auto-rollback

# Test: Can build/test modules without risk
```

#### Sprint 6: Multimodal + Resources
```python
# Extended capabilities:
aeris/multimodal/image_engine.py
aeris/multimodal/audio_engine.py
aeris/multimodal/video_engine.py
aeris/core/resource_monitor.py  # Spoon tracking

# Test: Processes media through Five Lenses
```

## Docker Compose Configuration

```yaml
# docker-compose.yml (Hardware-optimized for GTX 1660 SUPER)
version: '3.9'

x-nvidia: &nvidia
  deploy:
    resources:
      reservations:
        devices:
          - capabilities: [gpu]
            driver: nvidia
            count: 1

services:
  aeris-api:
    build: ./aeris
    container_name: aeris-api
    restart: unless-stopped
    depends_on:
      - chroma
      - ollama
    ports:
      - "8000:8000"
    environment:
      - AERIS_MODE=core
      - LLM_ENDPOINT=http://ollama:11434
      - VECTOR_DB_URL=http://chroma:8000
      - OLLAMA_NUM_PARALLEL=1  # Single inference for 6GB VRAM
      - OLLAMA_MAX_LOADED_MODELS=1
    volumes:
      - ./aeris:/app
      - ./uploads:/app/uploads:rw
      - ./logs:/app/logs:rw
      - ./models:/app/models:ro
      - ./data:/app/data:rw
    runtime: nvidia
    <<: *nvidia

  chroma:
    image: chromadb/chroma:latest
    container_name: aeris-chroma
    restart: unless-stopped
    ports:
      - "8001:8000"
    volumes:
      - ./data/chroma:/chroma
    environment:
      - ANONYMIZED_TELEMETRY=false
      - ALLOW_RESET=false

  ollama:
    image: ollama/ollama:latest
    container_name: aeris-ollama
    restart: unless-stopped
    ports:
      - "11434:11434"
    volumes:
      - ./data/ollama:/root/.ollama
    runtime: nvidia
    <<: *nvidia
    environment:
      - OLLAMA_NUM_PARALLEL=1
      - OLLAMA_MAX_LOADED_MODELS=1
      - OLLAMA_FLASH_ATTENTION=true  # Optimize for limited VRAM
```

## API Testing Suite

```http
# aeris/tests/api_tests.http

### 1. Health Check
GET http://localhost:8000/health

### 2. First Message
POST http://localhost:8000/core/message
Content-Type: application/json

{
  "text": "Hello AERIS, I need support today",
  "mode": "comfort"
}

### 3. Mode Switch (with consent)
POST http://localhost:8000/system/swap
Content-Type: application/json

{
  "type": "mode",
  "target": "muse",
  "reason": "Starting creative work"
}

### 4. Image Analysis (multimodal)
POST http://localhost:8000/media/analyze/image
Content-Type: multipart/form-data; boundary=boundary

--boundary
Content-Disposition: form-data; name="file"; filename="test.jpg"
Content-Type: image/jpeg

[binary data]
--boundary--

### 5. Memory Search
GET http://localhost:8000/memory/search?query=trauma&tier=episodic

### 6. Audit Trail
GET http://localhost:8000/audit/recent?limit=50

### 7. Narrator Log (plain language)
GET http://localhost:8000/narrator/log?hours=24
```

## Critical Implementation Notes

### 1. Five Lenses MUST be Unskippable
```python
# In mcp.py - enforce at protocol level:
class MCPBus:
    def __init__(self):
        # Five Lenses is ALWAYS first middleware
        self.add_middleware('pre', FiveLensesProcessor())
        self.add_middleware('post', EthicsGuard())
        # No way to bypass these
```

### 2. Auto-Rollback Pattern
```python
# In module_manager.py:
class ModuleManager:
    async def install_module(self, module):
        # 1. Snapshot current state
        snapshot = self.create_snapshot()
        
        try:
            # 2. Test in sandbox
            test_result = await sandbox.test(module)
            
            # 3. Validate through Lenses
            lens_result = await lenses.validate(module)
            
            # 4. Request consent
            consent = await consent_gate.request(
                f"Install {module.name}",
                risk_level=lens_result.risk
            )
            
            if not consent.approved:
                return False
            
            # 5. Install
            await self.promote_to_live(module)
            
        except Exception as e:
            # AUTO-ROLLBACK on ANY failure
            await self.restore_snapshot(snapshot)
            await narrator.explain(f"Rolled back due to: {e}")
            raise
```

### 3. Resource Monitoring (Spoons)
```python
# In resource_monitor.py:
class SpoonEstimator:
    def calculate_capacity(self):
        # Track GPU, CPU, Memory
        gpu_load = get_gpu_usage()
        cpu_load = psutil.cpu_percent()
        mem_available = psutil.virtual_memory().available
        
        # Map to "spoons" (0-10 scale)
        spoons = 10
        if gpu_load > 80: spoons -= 3
        if cpu_load > 70: spoons -= 2
        if mem_available < 2_000_000_000: spoons -= 2
        
        # Adjust operations based on capacity
        if spoons < 3:
            return "low_energy_mode"
        elif spoons < 6:
            return "balanced_mode"
        else:
            return "full_capability"
```

## Testing & Validation

### Acceptance Criteria Checklist:
- [ ] Boot completes in <5 seconds
- [ ] Five Lenses processes EVERY message
- [ ] Harmful content is blocked/reframed
- [ ] Consent required for all privileged actions
- [ ] Auto-rollback works on module failure
- [ ] Memory persists between sessions
- [ ] Mode switching requires appropriate consent
- [ ] Audit trail maintains chain integrity
- [ ] Narrator explains all technical actions
- [ ] Multimodal inputs go through same safety pipeline
- [ ] Resource monitor prevents overload
- [ ] Hot-swap works for LLM/TTS without restart

## Developer Handoff Commands

```bash
# For Paul - Quick Start:
git clone [repository]
cd aeris
chmod +x scripts/setup.ps1
./scripts/setup.ps1

# Verify installation:
curl http://localhost:8000/health

# Run tests:
python -m pytest tests/

# Monitor logs:
docker compose logs -f aeris-api

# Access shell:
python -m aeris.interface.shell
```

## Future Self-Building Capabilities

Once Phase 1-2 complete, AERIS can build:

1. **Avatar System** - Starting with 2D, evolving to 3D
2. **Mobile Companion** - PWA first, native apps later
3. **Health Tracking** - MS symptom patterns, medication reminders
4. **Creative Tools** - Story generation, art assistance
5. **Productivity Modules** - Task management, focus aids
6. **Community Features** - Module sharing (with privacy preserved)

## Final Notes

This architecture ensures:
- **Safety First** - Five Lenses + Nurturing + Consent gates
- **Privacy Always** - Local-first, encrypted, user-owned
- **Evolution with Boundaries** - Self-building but human-approved
- **Resource Aware** - Respects hardware and energy limits
- **Truly Yours** - Not corporate AI with a skin, but YOUR system

The beauty is that after Phase 2, AERIS becomes self-improving. She'll build what you need, when you need it, always checking if it helps you thrive.
